"""PLANNER REGRESSION — the unified roster planner (lib/plan.py) on synthetic leagues.

Every league here is built by hand: a State from rows (like test_system's _snap
helpers), a fake projection layer whose lines carry league points directly, a fake
schedule (kickoffs, byes), a real Wire over them (so the real gates run), and
Facts.from_parts. Nothing reads the live rosters; the ledger and registry are only
read (fictional names are on neither).
"""
import sys, copy, json
sys.path.insert(0, '/home/claude/bsb2')
from lib import clock as C, state as S, lineup as LU, wire as WR, plan as PL
from lib.facts import Facts
from lib.names import key as NK

bad = 0; total = 0
def case(label, ok, detail=''):
    global bad, total
    total += 1
    if not ok: bad += 1
    print(f'[{"OK " if ok else "FAIL"}] {label}' + (f'  — {detail}' if detail and not ok else ''))

print('=' * 88); print('PLANNER REGRESSION'); print('=' * 88)

# Pinned to a Thursday noon of the current NFL week: the BSB mechanics table turns every
# unrostered player into a claim between Tuesday 7 am and the Wednesday run, which is a
# fact about the calendar, not about these cases (10-06: six cases failed on a Tuesday).
_real = C.now()
WEEK = max(1, C.nfl_week(_real))
NOW = (C.week_start(WEEK) + C.dt.timedelta(days=2, hours=5)).astimezone(C.ET)     # Thu 12:00 ET
# the gates read the clock themselves (G12 state age, G8 freshness): pin it to the same
# Thursday, or a Saturday run sees a 48h-old 'live' state and blocks every add (10-17)
import os as _os
_os.environ['FF_NOW'] = NOW.strftime('%Y-%m-%dT%H:%M')
FUT = NOW + C.dt.timedelta(days=1)          # a kickoff still ahead
PAST = NOW - C.dt.timedelta(hours=2)        # a game in progress / started
OLD = NOW - C.dt.timedelta(hours=30)        # a game over

TEAMS = ['ARI', 'ATL', 'BAL', 'BUF', 'CAR', 'CHI', 'CIN', 'CLE', 'DAL', 'DEN', 'DET', 'GB', 'HOU', 'IND', 'JAX', 'KC',
         'LAC', 'LAR', 'LV', 'MIA', 'MIN', 'NE', 'NO', 'NYG', 'NYJ', 'PHI', 'PIT', 'SEA', 'SF', 'TB', 'TEN', 'WAS']
_SYL1 = ['Aber', 'Black', 'Castel', 'Dun', 'Ether', 'Fair', 'Golds', 'Holl', 'Inger', 'Jablon', 'Kettel', 'Lind', 'Montag',
         'Nakam', 'Okon', 'Pember', 'Quarter', 'Rasmus', 'Strick', 'Thistle']
_SYL2 = ['ford', 'wick', 'mont', 'stead', 'worth', 'by', 'ton', 'ley', 'dale', 'more', 'field', 'shaw']
import itertools as _it
SUR = (_SYL1[i % 20] + _SYL2[(i // 20) % 12] + ('' if i < 240 else 'abcdefghij'[(i // 240) % 10]) for i in _it.count())
FIRSTS = _it.cycle(['Zorvath', 'Quillon', 'Brexley', 'Talvin', 'Oswin', 'Pellam', 'Cadoc', 'Dravon', 'Elric', 'Fennick'])

def nm():
    return f'{next(FIRSTS)} {next(SUR)}'

DST_NAME = {'ARI': 'Arizona Cardinals', 'ATL': 'Atlanta Falcons', 'BAL': 'Baltimore Ravens', 'BUF': 'Buffalo Bills',
            'CAR': 'Carolina Panthers', 'CHI': 'Chicago Bears', 'NE': 'New England Patriots', 'NO': 'New Orleans Saints',
            'SEA': 'Seattle Seahawks', 'TB': 'Tampa Bay Buccaneers', 'TEN': 'Tennessee Titans', 'WAS': 'Washington Commanders'}


class FakeWindows:
    def __init__(self, byes=None):
        self.byes_ = byes or {}                      # {week: set(teams)}
        self.weeks = list(range(1, 19))
        self.own = {w: {t: 23.0 for t in TEAMS if t not in self.byes_.get(w, set())} for w in self.weeks}
        self.opp = {w: {t: 22.0 for t in TEAMS if t not in self.byes_.get(w, set())} for w in self.weeks}
    def byes(self, w): return sorted(self.byes_.get(w, set()))
    def have(self, w): return w in self.own
    def bye(self, t): return [w for w in self.weeks if t in self.byes_.get(w, set())]


class FakeProj:
    """Lines carry league points directly (pts_override), two source families."""
    def __init__(self, pts, kicks, ready=True):
        self.pts = pts; self.kicks = kicks; self.ready_ = ready
        self.week = WEEK; self.kal = {}; self.props = {}; self.games = {}
        self.off, self.idp = {}, {}
    def add(self, k, name, pos, tm):
        (self.idp if pos in ('LB', 'DE', 'DT', 'CB', 'S', 'DL', 'DB') else self.off)[k] = dict(player=name, team=tm, pos=pos)
    def line(self, k, pos, tm, market=True):
        k = NK(k); fam = WR._fam(pos)
        if k not in self.pts:
            return dict(stat={}, sources=[], prov={}, unknown=True, fam=fam)
        v = self.pts[k]
        return dict(stat={}, sources=['kalshi', 'sleeper'], prov={}, unknown=False, fam=fam, pts_override={'BSB': v, 'HH': v})
    def kickoff(self, tm): return self.kicks.get(tm, FUT)
    def market_ready(self, tm): return self.ready_ if not isinstance(self.ready_, dict) else self.ready_.get(tm, True)


def league(lg, roster, fas=(), others=(), kicks=None, byes=None, ready=True, usage=None, season=None,
           recently_added=None, recently_dropped=None, waived=None, log_rows=None, fab_left=93, registry=None):
    """roster: [(slot, name, pos, tm, pts, designation)] for Caleb's team; fas: [(name, pos, tm, pts)];
    others: [(owner, name, pos, tm, pts)]. -> (facts, state, proj)"""
    cfg = S.ALL[lg]
    rows = []
    pts = {}
    proj = FakeProj(pts, kicks or {}, ready)
    for slot, name, pos, tm, p, des in roster:
        rows.append(dict(owner=cfg.name, manager=cfg.name, slot=slot, player=name, pos=pos, nfl=tm, designation=des))
        k = f'DST:{tm}' if pos == 'DEF' else NK(name)
        if p is not None: pts[k] = p
        proj.add(k, name, pos, tm)
    for owner, name, pos, tm, p in others:
        rows.append(dict(owner=owner, manager=owner, slot='BN', player=name, pos=pos, nfl=tm, designation='none'))
        k = f'DST:{tm}' if pos == 'DEF' else NK(name)
        pts[k] = p; proj.add(k, name, pos, tm)
    for name, pos, tm, p in fas:
        k = NK(name)
        pts[k] = p; proj.add(k, name, pos, tm)
    stamp = NOW.isoformat(timespec='minutes')
    st = S.State(lg, rows, stamp, source='test', others_pulled=stamp)
    sea = season or {}
    w = WR.Wire(st, proj, season=sea if lg == 'BSB' else None)
    # hermetic: the live registry (data/roles.json) never leaks into a fixture (11-10: the
    # Vikings hold turned case 8a4's 'MIN' defense into an excluded spot)
    w.hold, w.drop_ok, w.verified, w.blocked = {}, {}, {}, set()
    for kind, entries in (registry or {}).items():
        getattr(w, kind).update(entries)
    lu = LU.solve(st, proj)
    use = {}
    for r in st.mine:
        if r['slot'] == 'BN' and WR._fam(r['pos']) in ('WR', 'RB', 'TE', 'QB'):
            use[r['key']] = dict(pos=WR._fam(r['pos']), snap_share=0.2, tgt_share=0.04, air_share=0.04, touch_share=0.05, gs=0)
    use.update(usage or {})
    f = Facts.from_parts(lg, st, proj, WEEK, NOW, w, lu, windows=FakeWindows(byes), season=sea,
                         usage_now=use, usage_prev={}, recently_added=recently_added or {}, recently_dropped=recently_dropped or {},
                         waived=waived or {}, log_rows=log_rows or [], fab_left=fab_left if lg == 'BSB' else None, usage_week=WEEK - 1)
    return f, st, proj


def bsb_roster(open_spots=0, k_tm='SEA', def_tm='BUF', qb_tm='DAL', te_tm='DET', k_des='none', extra=()):
    R = [('QB', nm(), 'QB', qb_tm, 20.0, 'none'), ('RB', nm(), 'RB', 'ATL', 14.0, 'none'), ('RB', nm(), 'RB', 'BAL', 12.0, 'none'),
         ('WR', nm(), 'WR', 'CAR', 13.0, 'none'), ('WR', nm(), 'WR', 'CHI', 11.0, 'none'), ('WR', nm(), 'WR', 'CIN', 9.0, 'none'),
         ('TE', nm(), 'TE', te_tm, 8.0, 'none'), ('W/R/T', nm(), 'WR', 'CLE', 9.5, 'none'),
         ('K', nm(), 'K', k_tm, 8.0, k_des), ('DEF', DST_NAME.get(def_tm, 'Buffalo Bills'), 'DEF', def_tm, 7.0, 'none')]
    bench = [('BN', nm(), 'WR', 'DEN', 4.0, 'none'), ('BN', nm(), 'WR', 'GB', 3.0, 'none'), ('BN', nm(), 'RB', 'HOU', 3.5, 'none'),
             ('BN', nm(), 'RB', 'IND', 2.0, 'none'), ('BN', nm(), 'WR', 'JAX', 2.5, 'none'), ('BN', nm(), 'TE', 'KC', 2.0, 'none'),
             ('BN', nm(), 'RB', 'LAC', 1.5, 'none'), ('BN', nm(), 'WR', 'LV', 1.0, 'none')]
    bench = bench[:8 - open_spots]
    return R + list(extra) + bench


def moves_of(p, kind='add'):
    return [m for m in p.moves if m['kind'] == kind]


# ---------------------------------------------------------------- 1. one open spot, two candidates
r1 = bsb_roster(open_spots=1)
a1, a2 = 'Wolfgang Ambrosetti', 'Lysander Breckenridge'
f, st, pr = league('BSB', r1, fas=[(a1, 'WR', 'MIA', 19.0), (a2, 'WR', 'MIN', 18.0)])
ev = dict(breakout_rows=[dict(key=NK(a1), name=a1, pos='WR', tm='MIA', tier='A', held='', usage='90% snaps', market='Kalshi agrees', in_pool=True, ahead=True),
                         dict(key=NK(a2), name=a2, pos='WR', tm='MIN', tier='A', held='', usage='88% snaps', market='Kalshi agrees', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
adds = moves_of(p)
opens = [m for m in adds if m['spot_kind'] == 'open']
case('one open spot + two candidates: exactly one move takes the open spot', len(opens) == 1, p.summary())
other = [m for m in adds if m['spot_kind'] != 'open']
rej = {r['key']: r for r in p.rejected}
case('...and the other gets a real drop or is rejected with a reason',
     (len(other) == 1 and any(t['op'] == 'drop' for t in other[0]['txns'])) or
     (len(other) == 0 and any(k in rej and rej[k]['reason'] for k in (NK(a1), NK(a2)) if k not in {m['add_key'] for m in adds})), p.summary())
case('each spot is used at most once', len({m['spot_id'] for m in adds}) == len(adds))
case('every add move prints its value terms', all(m['value_terms'] and 'dS_W1' in m['value_terms'] for m in adds))
pool = PL.SpotPool(f, PL.Mechanics(f))
pool.take(pool.spots[0].id, 'x')
try:
    pool.take(pool.spots[0].id, 'y'); reused = False
except PL.SpotReused:
    reused = True
case('SpotPool.take raises on reuse', reused)

# ---------------------------------------------------------------- 2. OUT starter -> firm replacement
r2 = bsb_roster()
r2[3] = ('WR', r2[3][1], 'WR', 'CAR', 13.0, 'O')            # WR1 tagged O, game ahead
f, st, pr = league('BSB', r2, ready=False)
p = PL.plan_facts(f, {})
lm = moves_of(p, 'lineup')
rep = [m for m in lm if m.get('sit') == r2[3][1]]
case('OUT starter: the replacement lineup move exists', len(rep) == 1, p.summary())
case('OUT starter: the replacement is FIRM with no market posted anywhere', rep and rep[0]['provisional'] is False, str(rep))
case('a swap NOT replacing an OUT starter with no market is provisional', all(m['provisional'] for m in lm if m.get('sit') != r2[3][1]))

# ---------------------------------------------------------------- 3. IR move frees a spot in the same plan (HH)
def hh_roster(extra_bench=(), qbs=('DAL', 'DET'), lb_des='none', lb_slot='LB'):
    R = [('QB', nm(), 'QB', qbs[0], 30.0, 'none'), ('WR', nm(), 'WR', 'CAR', 14.0, 'none'), ('RB', nm(), 'RB', 'ATL', 15.0, 'none'),
         ('TE', nm(), 'TE', 'DEN', 9.0, 'none'), ('W/R', nm(), 'WR', 'CHI', 12.0, 'none'), ('W/R/T', nm(), 'RB', 'BAL', 11.0, 'none'),
         ('Q/W/R/T', nm(), 'QB', qbs[1], 28.0, 'none'), ('K', nm(), 'K', 'SEA', 9.0, 'none'), ('DEF', 'Buffalo Bills', 'DEF', 'BUF', 20.0, 'none'),
         ('D', nm(), 'LB', 'CIN', 14.0, 'none'), ('DB', nm(), 'S', 'CLE', 12.0, 'none'), ('DL', nm(), 'DE', 'GB', 11.0, 'none'),
         (lb_slot, nm(), 'LB', 'HOU', 13.0, lb_des), ('CB', nm(), 'CB', 'IND', 10.0, 'none'), ('S', nm(), 'S', 'JAX', 10.5, 'none')]
    B = [('BN', nm(), 'WR', 'LAC', 6.0, 'none'), ('BN', nm(), 'WR', 'LV', 5.0, 'none'), ('BN', nm(), 'RB', 'MIA', 4.0, 'none'),
         ('BN', nm(), 'TE', 'NE', 3.0, 'none'), ('BN', nm(), 'WR', 'NO', 4.5, 'none'), ('BN', nm(), 'RB', 'NYG', 3.5, 'none')]
    B += list(extra_bench)
    while len(B) < 8: B.append(('BN', nm(), 'WR', 'PHI', 2.0, 'none'))
    return R + B[:8]

r3 = hh_roster(lb_des='IR')
ir_name = r3[12][1]
lbfa = 'Theodoric Vasquez-Lumley'
f, st, pr = league('HH', r3, fas=[(lbfa, 'LB', 'TEN', 16.0)],
                   registry=dict(drop_ok={NK(ir_name): dict(why='torn ACL, season over (test)', call='IR, NOT DROP', ir='True')}))
p = PL.plan_facts(f, {})
irm = [m for m in moves_of(p) if m['spot_kind'] == 'ir']
case('IR move frees a spot: the add uses the spot the IR move frees, in one Move',
     len(irm) == 1 and [t['op'] for t in irm[0]['txns']][:2] == ['ir', 'add'] and irm[0]['add_key'] == NK(lbfa), p.summary())
case('...and no separate drop is proposed for it', irm and not any(t['op'] == 'drop' for t in irm[0]['txns']))
f2, _, _ = league('HH', hh_roster(lb_des='IR'), registry=dict(drop_ok={}))
p2 = PL.plan_facts(f2, {})
case('a tagged-IR player with NO registry entry is not an IR spot (verified season-ending only)', not moves_of(p2, 'ir') and not any(m['spot_kind'] == 'ir' for m in moves_of(p2)))
r3o = hh_roster(lb_des='O'); ir_o = r3o[12][1]
f3, _, _ = league('HH', r3o, registry=dict(drop_ok={NK(ir_o): dict(why='season over (test)', call='IR', ir='True')}))
p3 = PL.plan_facts(f3, {})
im = moves_of(p3, 'ir')
case('an O-tagged verified IR player is an IR move marked ASK (provisional), not a firm spot', len(im) == 1 and im[0]['provisional'] and not any(m['spot_kind'] == 'ir' for m in moves_of(p3)), p3.summary())

# ---------------------------------------------------------------- 4. started player -> Tuesday timing
W1 = WEEK + 1
r4 = bsb_roster(k_tm='SEA')
k_name = r4[8][1]
kfa = 'Barnabas Quintrell'
START = dict(snap_share=0.9, tgt_share=0.25, air_share=0.3, touch_share=0.6, gs=1)
_u4 = {NK(x[1]): dict(START, pos=x[2]) for x in r4 if x[0] == 'BN'}
f, st, pr = league('BSB', r4, fas=[(kfa, 'K', 'NE', 9.0)], kicks={'SEA': PAST}, byes={W1: {'SEA'}}, usage=_u4)
p = PL.plan_facts(f, {})
km = [m for m in moves_of(p) if m['add_key'] == NK(kfa)]
case('started (week-locked) sole K on bye next week: the swap is Tuesday (week-lock)', len(km) == 1 and km[0]['when'].startswith('Tuesday'), p.summary())
case('...and in BSB the Tuesday add is a claim with a bid', km and any(t['op'] == 'claim' for t in km[0]['txns']) and '$' in km[0]['when'])
case('...and it drops the locked K only after the week rolls (no W points lost)', km and km[0]['value_terms']['dS_W'] == 0.0 and km[0]['eff'] == 'W+1')

# ---------------------------------------------------------------- 5. bye holes at K / DEF / QB / TE -> cover with timing
for fam, pos, kw, tmk, fa_tm in (('K', 'K', 'k_tm', 'SEA', 'NE'), ('DEF', 'DEF', 'def_tm', 'BUF', 'TB'), ('QB', 'QB', 'qb_tm', 'DAL', 'NO'), ('TE', 'TE', 'te_tm', 'DET', 'WAS')):
    r5 = bsb_roster(open_spots=1, **{kw: tmk})
    fa = DST_NAME[fa_tm] if pos == 'DEF' else nm()
    f, st, pr = league('BSB', r5, fas=[(fa, pos, fa_tm, 9.0 if pos != 'QB' else 18.0)], kicks={fa_tm: FUT}, byes={W1: {tmk} | ({'KC'} if pos == 'TE' else set())})
    p = PL.plan_facts(f, {})
    fk = f'DST:{fa_tm}' if pos == 'DEF' else NK(fa)
    mv = [m for m in moves_of(p) if m['add_key'] == fk]
    case(f'BSB bye hole at {fam} next week: the best free {fam} is the cover', len(mv) == 1 and 'hole' in mv[0]['srcs'], p.summary())
    case(f'...{fam} cover timing: a never-rostered free agent, before his kickoff', mv and mv[0]['when'].startswith('before kickoff'), mv and mv[0]['when'])
r5h = hh_roster()
k_h = r5h[7][1]
khfa = 'Mortimer Featherstonehaugh'
f, st, pr = league('HH', r5h, fas=[(khfa, 'K', 'TB', 9.0)], byes={W1: {'SEA'}}, kicks={'TB': OLD}, registry=dict(drop_ok={}),
                   usage={NK(x[1]): dict(START, pos=x[2]) for x in r5h if x[0] == 'BN'})
p = PL.plan_facts(f, {})
mv = [m for m in moves_of(p) if m['add_key'] == NK(khfa)]
case('HH bye hole at K next week: covered, swapping the K himself after he plays (Tuesday)', len(mv) == 1 and mv[0]['when'].startswith('Tuesday') and mv[0]['drop_name'] == k_h, p.summary())

# ---------------------------------------------------------------- 5b. the cover is found past the first few names (10-06: Santos hidden behind G5 kickers)
# BSB: my only K is on bye THIS week (hole at K in week W). Five free kickers rank above the
# cover but have already kicked (unusable for W); the sixth, still ahead of his kickoff,
# must be the cover — a hole search that stops at three names finds nobody.
r5b = [(sl, n, ps, tm, (0.0 if ps == 'K' else pt), d) for sl, n, ps, tm, pt, d in bsb_roster(open_spots=1, k_tm='KC')]   # the bye K projects nothing
kfas = [(nm(), 'K', tm, 13.0 - i) for i, tm in enumerate(('PIT', 'DET', 'NYJ', 'MIA', 'LV'))]
cover = 'Cairo Santosworth'
f, st, pr = league('BSB', r5b, fas=kfas + [(cover, 'K', 'CHI', 7.5)], byes={WEEK: {"KC"}},
                   kicks=dict({tm: OLD for _, _, tm, _ in kfas}, CHI=FUT, KC=None), registry=dict(drop_ok={}))   # KC: no game
p = PL.plan_facts(f, {})
mv = [m for m in moves_of(p) if m['add_key'] == NK(cover)]
case('a week-W hole is covered by the best free agent who can still play, however deep he ranks', len(mv) == 1 and 'hole' in mv[0]['srcs'], p.summary())
case('...and the hole reason leads the tile', mv and mv[0]['reasons'][0].startswith(f"week-{WEEK} hole at K"), mv and mv[0]['reasons'][:1])

# ---------------------------------------------------------------- 5c. no pulse on the wire (10-13: Achane, torn ACL, a $1 claim off a 264-pt preseason number)
# A free agent with NO weekly projection (this week or the last played weeks on disk)
# is OUT until a tag says otherwise, whatever his season number says — never an add,
# and his rest-of-season value is zero.
r5c = bsb_roster(open_spots=1)
ghost = 'Thaddeus Wraithbourne'
f, st, pr = league('BSB', r5c, fas=[(ghost, 'RB', 'MIA', None)], season={NK(ghost): dict(name=ghost, tm='MIA', pos='RB', pts=264.0)}, byes={W1: set()})
gx = f.fa(NK(ghost))
case('a free agent nobody projects is tagged O, not clear', gx is not None and gx.designation == 'O', gx and (gx.designation, gx.designation_src))
case('...and his rest-of-season value is zero, not season/17', gx is not None and (gx.ros_pw or 0) == 0.0 and (gx.pts_w1 or 0) == 0.0, gx and (gx.ros_pw, gx.pts_w1))
ev = dict(breakout_rows=[dict(key=NK(ghost), name=ghost, pos='RB', tm='MIA', tier='A', held='', usage='', market='', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
case('...and he is never an add, even into an open spot with Tier-A evidence', not any(m['add_key'] == NK(ghost) for m in p.moves), p.summary())
case('...rejected with G2 and the reason', any(r['key'] == NK(ghost) and r['reason'].startswith('G2') for r in p.rejected), [r for r in p.rejected if r['key'] == NK(ghost)])

# ---------------------------------------------------------------- 5c2. the feed went silent twice, this week included (11-18: Michael Wilson, neck fracture)
# Projected two weeks ago, blank last week and blank THIS week with a game on the schedule:
# dead, whatever week 9 said — and never a depth claim. One blank week (this one) with a
# projection last week is still alive (Mayfield, foot, uncertain: a tag's job, not the pulse's).
r5c2 = bsb_roster()
mw, bm = 'Mikhail Wilsonby', 'Bakari Mayfold'
f, st, pr = league('BSB', r5c2, fas=[(mw, 'WR', 'ARI', None), (bm, 'WR', 'TB', None)],
                   season={NK(mw): dict(name=mw, tm='ARI', pos='WR', pts=169.0), NK(bm): dict(name=bm, tm='TB', pos='WR', pts=180.0)}, byes={W1: set()})
f._past_proj_cache = {WEEK: set(), WEEK - 1: {NK(bm)}, WEEK - 2: {NK(mw), NK(bm)}, WEEK - 3: {NK(mw), NK(bm)}}
f._pool_cache.pop(NK(mw), None); f._pool_cache.pop(NK(bm), None)
gw, gb = f.fa(NK(mw)), f.fa(NK(bm))
case('pulse: blank this week AND last week (team playing both) is dead, even though week W-2 projected him', gw is not None and gw.designation == 'O' and (gw.ros_pw or 0) == 0.0, gw and (gw.designation, gw.designation_src, gw.ros_pw))
case('pulse: one blank week with a projection last week is still alive', gb is not None and gb.designation == 'none', gb and (gb.designation, gb.designation_src))
p = PL.plan_facts(f, dict())
case('...and the dead one is never a depth claim', not any(m.get('add_key') == NK(mw) for m in p.moves), p.summary())
# on bye THIS week the current week is not a played week: last two played weeks decide
f, st, pr = league('BSB', r5c2, fas=[(mw, 'WR', 'ARI', None)], season={NK(mw): dict(name=mw, tm='ARI', pos='WR', pts=169.0)}, byes={WEEK: {'ARI'}, W1: set()})
f._past_proj_cache = {WEEK: set(), WEEK - 1: {NK(mw)}, WEEK - 2: {NK(mw)}, WEEK - 3: {NK(mw)}}
f._pool_cache.pop(NK(mw), None)
case('pulse: a bye this week is not a silent week', f.fa(NK(mw)).designation == 'none', f.fa(NK(mw)).designation_src)

from lib import stash as _STv
import tempfile as _tf, os as _osv, json as _jsv
_rt = _tf.mkdtemp(); _osv.makedirs(_osv.path.join(_rt, 'data'))
_jsv.dump(dict(stash={'Michael Wilson': dict(verdict='season'), '_why': 'x'}), open(_osv.path.join(_rt, 'data', 'roles.json'), 'w'))
case('stash verdicts are keyed canonically (a verdict typed "Michael Wilson" hits the blend\'s key)', NK('Michael Wilson') in _STv.verified(_rt) and '_why' in _STv.verified(_rt), str(list(_STv.verified(_rt))))

# ---------------------------------------------------------------- 5e. a rival's drop of a real role is a fact (10-25: Terry McLaurin)
# McLaurin, season 204, projected in his last played game (week 6), knee on Monday night,
# out for the season; WAS on bye in week 7 so no projection exists to go missing, and the
# pulse (5c) read him alive. WINdianapolis dropped him Saturday. The planner priced a $1
# claim into a bench spot. A manager who let a 100+ point role go after his last game knows
# something; the add waits for a person (registry add_yes clears it).
r5e = bsb_roster(open_spots=1)
tmac = 'Thaddeus Mcelroy-Vance'
_log5e = [dict(datetime=(NOW - C.dt.timedelta(hours=20)).strftime('%Y-%m-%d %H:%M'), team='WINdianapolis', action='Drop', player=tmac, pos='WR', nfl='WAS', note='To Waivers')]
f, st, pr = league('BSB', r5e, fas=[(tmac, 'WR', 'WAS', 12.0)], season={NK(tmac): dict(name=tmac, tm='WAS', pos='WR', pts=204.0)}, byes={W1: set()}, log_rows=_log5e)
gx = f.fa(NK(tmac))
case('rival drop: the fact names the team and the day', gx is not None and gx.get('rival_drop') and gx['rival_drop'][0] == 'WINdianapolis', gx and gx.get('rival_drop'))
p = PL.plan_facts(f, dict(breakout_rows=[dict(key=NK(tmac), name=tmac, pos='WR', tm='WAS', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)]))
case('rival drop: a 100+ point role a rival dropped this week is not an add, even into an open spot', not any(m['add_key'] == NK(tmac) for m in moves_of(p)), p.summary())
case('...rejected with G15 and the team named', any(r['key'] == NK(tmac) and r['reason'].startswith('G15') and 'WINdianapolis' in r['reason'] for r in p.rejected), [r for r in p.rejected if r['key'] == NK(tmac)])
# the clearance: a registry add_yes (a person looked) lets him through
f2, st2, pr2 = league('BSB', r5e, fas=[(tmac, 'WR', 'WAS', 12.0)], season={NK(tmac): dict(name=tmac, tm='WAS', pos='WR', pts=204.0)}, byes={W1: set()}, log_rows=_log5e,
                      registry=dict(verified={NK(tmac): dict(priority=1, why='verified healthy (test)', team='WAS', pos='WR', as_of=NOW.date().isoformat())}))
p2 = PL.plan_facts(f2, dict())
case('...a registry add_yes clears the rival-drop block', not any(r['key'] == NK(tmac) and r['reason'].startswith('G15') for r in p2.rejected), [r['reason'][:60] for r in p2.rejected if r['key'] == NK(tmac)])
# my own drop is not a rival drop (5c/9 cover that); a 30-point body dropped by a rival is not a signal
_log5e2 = [dict(_log5e[0], team=S.ALL['BSB'].name)]
f3, st3, pr3 = league('BSB', r5e, fas=[(tmac, 'WR', 'WAS', 12.0)], season={NK(tmac): dict(name=tmac, tm='WAS', pos='WR', pts=204.0)}, byes={W1: set()}, log_rows=_log5e2)
case('...my own drop is not a rival drop', f3.fa(NK(tmac)) is not None and not f3.fa(NK(tmac)).get('rival_drop'))

# ---------------------------------------------------------------- 5g. a bye is not a zero season (11-04: T.J. Watt, PIT bye, 'no number from any source')
# A rostered IDP with no season number and no line THIS week (his team is on bye) is valued
# off his neighbouring weeks, not 0 — else he is the planner's drop for any Tier-B body.
r5g = hh_roster()
_dl5g = [r for r in r5g if r[0] == 'DL'][0]
r5g = [(r[0], r[1], r[2], r[3], 0.0, r[5]) if r[0] == 'DL' else r for r in r5g]
f, st, pr = league('HH', r5g, byes={WEEK: {_dl5g[3]}, W1: set()})
dd = f.mine[NK(_dl5g[1])]
dd_alt = f._offbye_proj(NK(_dl5g[1]), dd.fam, dd.tm)
case('bye week: a player with no season number and no game this week is not worth 0 for the year when a neighbouring week prices him',
     (dd.ros_pw or 0) > 0 or dd_alt[0] is None, (dd.ros_pw, dd.ros_src, dd_alt))

# ---------------------------------------------------------------- 5h. an unpriced STARTER is unknown, not zero (11-07: Garrett back from IR, no Sleeper row yet)
r5h = hh_roster()
_dl5h = [r for r in r5h if r[0] == 'DL'][0]
r5h = [(r[0], r[1], r[2], r[3], None, r[5]) if r[0] == 'DL' else r for r in r5h]
f, st, pr = league('HH', r5h, byes={W1: set()}, registry=dict(hold={NK(_dl5h[1]): dict(why='back from IR, verified (test)', call='HOLD')}))
dd = f.mine[NK(_dl5h[1])]
case('unpriced starter: his week-W value is the positional median (never None, never 0) when he has a game and no OUT tag',
     dd.pts_w is None and (f.value(dd, WEEK) or 0) > 0, (dd.pts_w, f.value(dd, WEEK), dd.kick))
case('...and a registry hold with no feed is valued rest-of-season at the median, not zero', (dd.ros_pw or 0) > 0 and 'registry hold' in (dd.ros_src or ''), (dd.ros_pw, dd.ros_src))
p = PL.plan_facts(f, dict())
case('...so the planner never calls his slot empty nor names him the drop', not any(m.get('kind') == 'lineup' and m.get('slot') == 'DL' for m in p.moves) and not any(m.get('drop_name') == _dl5h[1] for m in p.moves), p.summary())

# ---------------------------------------------------------------- 5f. a stash verdict is permanent (11-01: McLaurin resurfaced after the 7-day rival-drop window)
r5f = bsb_roster(open_spots=1)
tmac2 = 'Thaddeus Mcelroy-Vance'
f, st, pr = league('BSB', r5f, fas=[(tmac2, 'WR', 'WAS', 12.0)], season={NK(tmac2): dict(name=tmac2, tm='WAS', pos='WR', pts=204.0)}, byes={W1: set()})
f.stash_verdicts = {NK(tmac2): dict(verdict='season', as_of='2026-10-25', why='knee, out for the season (test)')}
p = PL.plan_facts(f, dict(breakout_rows=[dict(key=NK(tmac2), name=tmac2, pos='WR', tm='WAS', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)]))
case('stash verdict season: never an add, whatever the window', not any(m['add_key'] == NK(tmac2) for m in moves_of(p)) and any(r['key'] == NK(tmac2) and 'out for the season' in r['reason'] for r in p.rejected), p.summary())


# A free agent with NO season number and a big W projection is valued rest-of-season at
# the positional median at most — one week's number from the most volatile source
# cannot carry the rest/playoff terms of the objective (Moreau: a 0.02/0.88 Kalshi quote
# read as 20 pts, 18/wk rest-of-season, J +15 over McBride).
r5d = bsb_roster(open_spots=1)
flash = 'Orsino Quillfeather'
f, st, pr = league('BSB', r5d, fas=[(flash, 'TE', 'HOU', 20.0)], byes={W1: set()})
gx = f.fa(NK(flash))
_med = f.posmed.get('TE')
case('no season number: rest-of-season is capped at the positional median, not the W projection', gx is not None and _med is not None and abs((gx.ros_pw or 0) - _med) < 1e-6 and gx.ros_pw < 20.0, gx and (gx.ros_pw, gx.ros_src, _med))
case('...and the source says why', gx is not None and 'positional median' in (gx.ros_src or ''), gx and gx.ros_src)
# the market side of the same case: an empty-quote ladder is no ladder
from lib import market as MK
_rows5d = [dict(ticker=f'KXNFLRECYDS-26OCT25NYGHOU-HOUX-{s}', yes_bid='0.0200', yes_ask='0.8800') for s in (10, 20, 25, 30, 40)]
case('market: a ladder quoted 2c/88c at every strike yields no points', MK._clean_ladder(_rows5d) == [], MK._clean_ladder(_rows5d))
_rows5d2 = [dict(ticker=f'KXNFLRECYDS-26OCT25NYGHOU-HOUX-{s}', yes_bid=f'{p-0.04:.4f}', yes_ask=f'{p+0.04:.4f}') for s, p in ((10, 0.90), (20, 0.70), (25, 0.55), (30, 0.40), (40, 0.20))]
case('market: a real 8c-wide ladder is kept whole', len(MK._clean_ladder(_rows5d2)) == 5)
_rows5d3 = [dict(ticker=f'KXNFLPASSTDS-26NOV08ARISEA-SEASDARNOLD14-{s}', yes_bid='0.0000', yes_ask='0.9500', volume='0.00', last_price='0.0000') for s in (2, 3, 4, 5)]
case('market: an ask-only placeholder ladder (0.00/0.95, nothing traded) yields no points (11-04: 90 pass TDs)', MK._clean_ladder(_rows5d3) == [], MK._clean_ladder(_rows5d3))
_rows5d4 = [dict(ticker=f'KXNFLREC-26NOV08ARISEA-SEAX-{s}', yes_bid='0.0000', yes_ask='0.6000', volume='120.00', last_price='0.5800') for s in (3, 4, 5)]
case('market: a one-sided quote that HAS traded is kept', len(MK._clean_ladder(_rows5d4)) == 3)

# ---------------------------------------------------------------- 6. owned player never a candidate
r6 = bsb_roster(open_spots=1)
own = 'Aurelio Pendergast'
f, st, pr = league('BSB', r6, others=[('Rayland', own, 'WR', 'PIT', 25.0)])
ev = dict(breakout_rows=[dict(key=NK(own), name=own, pos='WR', tm='PIT', tier='A', held='', usage='', market='', in_pool=True, ahead=True)],
          upgrades=[dict(fam='WR', add=dict(key=NK(own), name=own, week=25.0), over=dict(player='x', pts=1.0))])
p = PL.plan_facts(f, ev)
case('an owned player is never an add, whatever the evidence says', not any(m['add_key'] == NK(own) for m in p.moves))
case('...and the considered list says why', any(r['key'] == NK(own) for r in p.rejected), str(p.rejected))

# ---------------------------------------------------------------- 7. recently dropped never a candidate
r7 = bsb_roster(open_spots=1)
rd = 'Cuthbert Ravenhill'
f, st, pr = league('BSB', r7, fas=[(rd, 'WR', 'PIT', 25.0)], recently_dropped={NK(rd): ('HH', '2026-10-02')})
ev = dict(breakout_rows=[dict(key=NK(rd), name=rd, pos='WR', tm='PIT', tier='A', held='', usage='', market='', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
case('a player Caleb dropped (either league, <= 7 days) is never an add', not any(m['add_key'] == NK(rd) for m in p.moves))
case('...rejected with the reason', any(r['key'] == NK(rd) and 'dropped him' in r['reason'] for r in p.rejected), str(p.rejected))

# ---------------------------------------------------------------- 8. superflex QB3 never a drop
qb3 = nm()
r8 = hh_roster(extra_bench=[('BN', qb3, 'QB', 'MIN', 1.0, 'none')])
wrfa = 'Ignatius Blatherwick'
f, st, pr = league('HH', r8, fas=[(wrfa, 'WR', 'PIT', 30.0)], registry=dict(drop_ok={}),
                   usage={NK(qb3): dict(pos='QB', snap_share=0.0, tgt_share=0, air_share=0, touch_share=0, gs=0)})
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(wrfa), name=wrfa, week=30.0), over=dict(player='x', pts=12.0))])
p = PL.plan_facts(f, ev)
case('superflex: QB3 is never the drop', not any(t['op'] == 'drop' and t['key'] == NK(qb3) for m in p.moves for t in m['txns']), p.summary())
case('...he is listed as not a clean drop, with G14', any(e['player'] == qb3 and 'G14' in e['reason'] for e in p.excluded), str(p.excluded))

# ---------------------------------------------------------------- 8a2. a DEF/K is fungible in later weeks (10-23: Quay Walker for the Chiefs)
# HH: the IDP flex holds a LB on bye; the spare DEF covers next week's DEF bye. A verified
# every-down LB (registry add_yes priority 1) for the spare DEF: this week +LB, and next
# week's DEF slot is NOT empty — the engine streams the best free DEF — so W+1 is not a
# -18 and the depth term does not charge the spare's whole season. The move ships.
r8a2 = hh_roster(extra_bench=[('BN', 'Kansas City', 'DEF', 'KC', 18.0, 'none'), ('BN', nm(), 'CB', 'TEN', 13.0, 'none')])
_lb_bye = [r for r in r8a2 if r[0] == 'D'][0]
# IDP drops are legal now (10-28): both linebackers are registry holds here so the case
# keeps testing the spare-DEF spot, not an LB-for-LB upgrade
_lb_hold = {NK(r[1]): dict(why='hold (test)', call='HOLD') for r in r8a2 if r[2] not in ('DEF', 'K')}     # every skill player and IDP held: the case is about the spare DEF's valuation
_lb_hold['DST:BUF'] = dict(why='the December DEF (test)', call='HOLD')                                                                    # so the spare is the only DEF spot
walker = 'Quayshawn Ironmonger'
f, st, pr = league('HH', r8a2, fas=[(walker, 'LB', 'LV', 19.5), ('Dallas Cowboys', 'DEF', 'DAL', 17.5)],
                   kicks={_lb_bye[3]: None}, byes={WEEK: {_lb_bye[3]}, W1: {"BUF"}},
                   registry=dict(verified={NK(walker): dict(priority=1, why='every-down LB (test)', team='LV', pos='LB', as_of=NOW.date().isoformat())}, hold=_lb_hold))
p = PL.plan_facts(f, dict())
m8a2 = next((m for m in p.moves if m.get('add_key') == NK(walker)), None)
case('fungible DEF: a verified LB takes the spare DEF for the IDP flex', m8a2 is not None, p.summary())
_junk8a2 = {r[1] for r in r8a2 if r[0] == 'BN' and r[2] not in ('DEF', 'K') and r[4] <= 3.0}        # a 3-point body ties the spare on J; either is 'not a real player'
case('...the drop is the spare DEF (or a 3-point body that ties it), never a real player', m8a2 is not None and (m8a2.get('spot_kind') == 'spare' or m8a2.get('drop_name') in _junk8a2), m8a2 and (m8a2.get('spot_kind'), m8a2.get('drop_name'), m8a2.get('value_terms'), sorted(_junk8a2)))
case('...next week is valued with the best free DEF in the slot, not an empty slot', m8a2 is not None and m8a2['value_terms']['dS_W1'] > -5.0, m8a2 and m8a2['value_terms'])
case('...and the spare DEF is not charged as depth beyond the free replacement', m8a2 is not None and m8a2['value_terms']['d_depth'] > -2.0, m8a2 and m8a2['value_terms'])

# ---------------------------------------------------------------- 8a3. a DEF/K HOLE may take a replacement-level bench spot (10-28)
# HH, the only DEF on bye THIS week and a registry hold (the Texans), no spare, no open
# spot: the slot is empty on Sunday. The bench holds a 5th DB below the free agents at
# his position and a real WR. 'A DEF never costs a skill player or an IDP' is a rule
# about streams; a HOLE fills from the replacement-level body — never from the real one.
r8a3 = hh_roster(extra_bench=[('BN', nm(), 'CB', 'TEN', 9.0, 'none'), ('BN', nm(), 'WR', 'PHI', 15.0, 'none')])
r8a3 = [(r[0], r[1], r[2], r[3], 0.0, r[5]) if r[0] == 'DEF' else r for r in r8a3]          # on bye this week: no game, no points
_def8a3 = [r for r in r8a3 if r[0] == 'DEF'][0]
_cb8a3 = [r for r in r8a3 if r[0] == 'BN' and r[2] == 'CB'][0]
_wr8a3 = [r for r in r8a3 if r[0] == 'BN' and r[2] == 'WR' and r[4] == 15.0][0]
_hold8a3 = {NK(r[1]): dict(why='hold (test)', call='HOLD') for r in r8a3 if r[0] not in ('DEF',) and r[1] not in (_cb8a3[1], _wr8a3[1])}
_hold8a3['DST:' + _def8a3[3]] = dict(why='the December DEF (test)', call='HOLD')
f, st, pr = league('HH', r8a3, fas=[('Washington Commanders', 'DEF', 'WAS', 21.0), ('Derwin James', 'DB', 'LAC', 16.0), ('Talanoa Hufanga', 'DB', 'DEN', 15.5), ('Quandre Diggs', 'DB', 'TEN', 15.0)],
                   kicks={_def8a3[3]: None}, byes={WEEK: {_def8a3[3]}, W1: set()}, registry=dict(hold=_hold8a3))
p = PL.plan_facts(f, dict())
m8a3 = next((m for m in moves_of(p) if m['add_key'] == NK('Washington Commanders')), None)
case('DEF hole: the empty slot is filled from the wire even with no spare and no open spot', m8a3 is not None, p.summary())
case('...the spot is the replacement-level 5th DB, not the real WR', m8a3 is not None and m8a3.get('drop_name') == _cb8a3[1], m8a3 and m8a3.get('drop_name'))
case('...and the move is firm (a hole, not an edge)', m8a3 is not None and not m8a3.get('provisional'), m8a3 and m8a3.get('provisional'))

# ---------------------------------------------------------------- 8a4. a DEF stream may take a dead bench body (10-28, Caleb's Strong-for-Commanders)
# BSB: two DEFs (the spare has the better matchup NEXT week than any free DEF), a bench RB
# at 0.75/wk below the free agents at RB, and a free DEF that beats both of mine THIS week.
# The engine named the spare; Caleb dropped the dead RB and kept the spare for its week-9
# game. The rule 'a stream never costs a skill player' is about REAL players.
r8a4 = bsb_roster(def_tm='MIN', extra=[('BN', 'San Francisco', 'DEF', 'SF', 5.0, 'none')])
r8a4 = [r for r in r8a4 if not (r[0] == 'BN' and r[3] == 'LV')]
_dead = next(r for r in r8a4 if r[0] == 'BN' and r[2] == 'RB' and r[4] == 1.5)
f, st, pr = league('BSB', r8a4, fas=[('Washington Commanders', 'DEF', 'WAS', 12.0), ('Kenny Gainwell', 'RB', 'TB', 7.0), ('Zonovan Knight', 'RB', 'NYJ', 6.0)], byes={W1: set()})
# next week: the spare 49ers 19 on the look-ahead, the best free DEF 9 — no free unit replaces him
for k, d in f.mine.items():
    if k == 'DST:SF': d['pts_w1'] = 19.0
p = PL.plan_facts(f, dict(upgrades=[dict(fam='DEF', add=dict(key='DST:WAS', name='Washington Commanders', week=12.0), over=dict(player='Minnesota Vikings', pts=7.0))]))
m8a4 = next((m for m in moves_of(p) if m['add_key'] == 'DST:WAS'), None)
case('DEF stream: a free DEF that beats both of mine this week ships', m8a4 is not None, p.summary())
case('...and the spot is never the spare DEF that holds next week\'s matchup (the dead RB or the worse DEF one-for-one)', m8a4 is not None and m8a4.get('drop_name') in (_dead[1], 'Buffalo Bills') and m8a4.get('drop_name') != 'San Francisco', m8a4 and (m8a4.get('spot_kind'), m8a4.get('drop_name')))
case('...the dead RB is a LEGAL spot for the stream (not blocked as a real player)', not any(r['key'] == 'DST:WAS' and 'never costs a real bench player' in r['reason'] for r in p.rejected))
# a real bench RB (above replacement) is still never the spot for a stream
r8a4b = [(r[0], r[1], r[2], r[3], 12.0, r[5]) if r[1] == _dead[1] else r for r in r8a4]
f2, st2, pr2 = league('BSB', r8a4b, fas=[('Washington Commanders', 'DEF', 'WAS', 12.0), ('Kenny Gainwell', 'RB', 'TB', 7.0)], byes={W1: set()})
for k, d in f2.mine.items():
    if k == 'DST:SF': d['pts_w1'] = 19.0
p2 = PL.plan_facts(f2, dict(upgrades=[dict(fam='DEF', add=dict(key='DST:WAS', name='Washington Commanders', week=12.0), over=dict(player='Minnesota Vikings', pts=7.0))]))
m8a4b = next((m for m in moves_of(p2) if m['add_key'] == 'DST:WAS'), None)
case('...a real bench RB (12/wk, above replacement) is never a stream\'s spot', m8a4b is None or m8a4b.get('drop_name') != _dead[1], m8a4b and m8a4b.get('drop_name'))

# ---------------------------------------------------------------- 8a5. a bye-week hole fills from the spare DEF, never by cutting the bye man (11-05: Watt)
# HH: Watt (LB listed, in the DL slot) on bye, no bench DL; the spare DEF on the bench; the
# best free DL has one source (IDP always does). Expected: the free DL ships into the DL
# slot, G5 is a WARN (the slot is a verified zero), the spot is the spare DEF, and Watt stays.
r8a5 = hh_roster(extra_bench=[('BN', 'Kansas City', 'DEF', 'KC', 18.0, 'none')])
_dl8a5 = [r for r in r8a5 if r[0] == 'DL'][0]
r8a5 = [(r[0], r[1], r[2], r[3], 0.0, r[5]) if r[0] == 'DL' else r for r in r8a5]
_hold8a5 = {NK(r[1]): dict(why='hold (test)', call='HOLD') for r in r8a5 if r[0] not in ('DL',) and r[2] not in ('DEF',)}
_hold8a5['DST:BUF'] = dict(why='the December DEF (test)', call='HOLD')
f, st, pr = league('HH', r8a5, fas=[('Boye Mafe', 'DE', 'CIN', 13.2), ('Austin Booker', 'DE', 'CHI', 14.8)],
                   kicks={_dl8a5[3]: None}, byes={WEEK: {_dl8a5[3]}, W1: set()}, registry=dict(hold=_hold8a5))
# the bye man is a real starter (Watt: 12/wk from his last played weeks, facts._offbye_proj);
# a fixture body worth 0 for the year is legally the spot for a 14-pt cover (11-10)
f.mine[NK(_dl8a5[1])]['ros_pw'] = 12.0; f.mine[NK(_dl8a5[1])]['ros_src'] = 'test: off-bye projection'
p = PL.plan_facts(f, dict())
m8a5 = next((m for m in moves_of(p) if m['add_key'] in (NK('Austin Booker'), NK('Boye Mafe'))), None)
case('bye hole at DL: the best free DL ships into the empty slot despite one source (the slot is a verified zero)', m8a5 is not None, p.summary())
case('...the spot is the spare DEF, and the bye man is never cut for his own one-week hole', m8a5 is not None and m8a5.get('spot_kind') == 'spare' and m8a5.get('drop_name') != _dl8a5[1], m8a5 and (m8a5.get('spot_kind'), m8a5.get('drop_name')))

# ---------------------------------------------------------------- 8b. FAB policy (Caleb, 10-13: every policy decision maximizes P(win the league))
# A firm claim (hole cover) bids to WIN it — the league's 75th-pct winning bid — from
# the money above the reserve; the reserve is for a Tier-A player and steps down.
import lib.fab as _FAB, lib.rules as _RU
_LADDER = [0, 0, 0, 1, 1, 2, 3, 5, 5, 6, 7, 10, 11, 15, 24, 66]        # 16 bids: 75th pct -> index 11 -> $10
_real_model = _FAB.model
_FAB.model = lambda: dict(n=len(_LADDER), bids=list(_LADDER), bands={'B': dict(bid=1), 'A': dict(bid=25), 'contested': dict(bid=67)}, med=5, spent={}, remaining={})
try:
    case('rules: the ladder\'s 75th-pct bid is $10 on this ladder', _RU.fab_bid_firm(_LADDER) == 10, _RU.fab_bid_firm(_LADDER))
    case('rules: the reserve is $60 through week 10, $30 through 12, $0 after', (_RU.fab_reserve(6), _RU.fab_reserve(11), _RU.fab_reserve(13)) == (60, 30, 0))
    # week-W+1 hole at K in BSB (sole K on bye next week, started this week -> Tuesday claim)
    r8b = bsb_roster()
    kb = 'Barnaby Quillfeather'
    f, st, pr = league('BSB', r8b, fas=[(kb, 'K', 'NE', 9.0)], kicks={'SEA': PAST}, byes={W1: {'SEA'}}, usage=_u4, fab_left=93)
    p = PL.plan_facts(f, {})
    km = [m for m in moves_of(p) if m['add_key'] == NK(kb)]
    bid = km and next((t.get('bid') for t in km[0]['txns'] if t['op'] == 'claim'), None)
    case('a firm hole-cover claim bids the 75th-pct winning bid ($10), not the $1 floor', bid == 10, (bid, p.summary()))
    _res8b = _RU.fab_reserve(WEEK)                                     # the reserve steps down by week ($60 through 10, $30 through 12, then 0)
    f, st, pr = league('BSB', r8b, fas=[(kb, 'K', 'NE', 9.0)], kicks={'SEA': PAST}, byes={W1: {'SEA'}}, usage=_u4, fab_left=_res8b + 3)
    p = PL.plan_facts(f, {})
    km = [m for m in moves_of(p) if m['add_key'] == NK(kb)]
    bid = km and next((t.get('bid') for t in km[0]['txns'] if t['op'] == 'claim'), None)
    case(f'...capped by the reserve: ${_res8b + 3} left in week {WEEK} leaves $3 above the ${_res8b} reserve', bid == 3, (bid, p.summary()))
    case('...and the claim still ships (money above the reserve is nearly free)', len(km) == 1, p.summary())
    f, st, pr = league('BSB', r8b, fas=[(kb, 'K', 'NE', 9.0)], kicks={'SEA': PAST}, byes={W1: {'SEA'}}, usage=_u4, fab_left=5)
    p = PL.plan_facts(f, {})
    km = [m for m in moves_of(p) if m['add_key'] == NK(kb)]
    bid = km and next((t.get('bid') for t in km[0]['txns'] if t['op'] == 'claim'), None)
    case('...never below $1, never above what is left', bid == 1, (bid, p.summary()))
finally:
    _FAB.model = _real_model

# ---------------------------------------------------------------- 8c. lineup pairing with several bye starters (10-13: 'Pierce at W/R/T over Vikings')
# Three starters on bye THIS week (WR3, TE, DEF). Two free agents arrive — an RB who takes
# W/R/T and a defense. Each must be paired with a displaced starter ELIGIBLE for the slot
# he takes: the DEF over the bye DEF, the RB over a bye WR/TE, never a defense over a flex.
r8c = bsb_roster(open_spots=2)
r8c = [(sl, n, ps, tm, (0.0 if sl in ('DEF', 'TE') or (sl == 'WR' and tm == 'CIN') else pt), d) for sl, n, ps, tm, pt, d in r8c]
rb8c, df8c = 'Osric Pendleton', DST_NAME['SEA']
f, st, pr = league('BSB', r8c, fas=[(rb8c, 'RB', 'PHI', 9.0), (df8c, 'DEF', 'SEA', 7.5)],
                   kicks={'BUF': None, 'DET': None, 'CIN': None}, byes={W1: set()},
                   usage={NK(rb8c): dict(START, pos='RB')})
ev = dict(breakout_rows=[dict(key=NK(rb8c), name=rb8c, pos='RB', tm='PHI', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
lu = {m['add_key']: m.get('lineup') for m in moves_of(p)}
rb_over = (lu.get(NK(rb8c)) or {}).get('over', ''); df_over = (lu.get('DST:SEA') or {}).get('over', '')
case('a newcomer at W/R/T is paired with a displaced WR/TE, never the bye defense', lu.get(NK(rb8c)) is not None and 'Bills' not in rb_over, (rb_over, p.summary()))
case('...and the new defense is paired with the bye defense', lu.get('DST:SEA') is not None and df_over.startswith('Buffalo'), (df_over, p.summary()))

# ---------------------------------------------------------------- 8d. a published pair sticks through a near-tie (10-13: Jennings <-> Hutchinson flipped between two pulls)
r8d = [(sl, n, ps, tm, (1.0 if (sl == 'BN' and tm == 'LAC') else pt), d) for sl, n, ps, tm, pt, d in bsb_roster(open_spots=0)]   # bench WR (LV) and bench RB (LAC) both at 1.0
rbx = 'Lysander Thorncroft'
f, st, pr = league('BSB', r8d, fas=[(rbx, 'RB', 'PHI', 12.0)], byes={W1: {'ATL', 'BAL'}}, usage={NK(rbx): dict(START, pos='RB')})   # both RBs on bye next week: a hole, so every bench spot is in play
ev = dict(breakout_rows=[dict(key=NK(rbx), name=rbx, pos='RB', tm='PHI', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)])
p0 = PL.plan_facts(f, ev)
m0 = next((m for m in moves_of(p0) if m['add_key'] == NK(rbx)), None)
# the two cheapest bench spots are near-equal (bench WRs at 1.0 and 2.5); take whichever
# the plan picked, then publish the OTHER as the prior plan and re-run: it must stick
# the feasible bench spots (same family as the add) tie at J; publish the one
# the plan did NOT pick as the prior plan and re-run: it must stick
bench_low = sorted([x for x in r8d if x[0] == 'BN' and x[2] == 'RB'], key=lambda x: x[4])     # the bench RBs tie at J (bench value is not in J)
other = next(x for x in bench_low if m0 and x[1] != m0['drop_name'])
f.prev_plan_pairs = {(NK(rbx), f'drop:{NK(other[1])}')}
p1 = PL.plan_facts(f, ev)
m1 = next((m for m in moves_of(p1) if m['add_key'] == NK(rbx)), None)
case('a near-tie between two bench spots keeps the spot already published', m0 is not None and m1 is not None and m1['drop_name'] == other[1], (m0 and m0['drop_name'], m1 and m1['drop_name']))
_worse = next(x for x in r8d if x[0] == 'BN' and x[2] == 'RB' and x[4] >= 3.0)      # the 3.5 bench RB: depth cost 0.2 x (3.5 - 1.0) = 0.5 worse, plus churn ordering
f.prev_plan_pairs = {(NK(rbx), 'drop:' + NK(_worse[1]))}
p2 = PL.plan_facts(f, ev)
m2 = next((m for m in moves_of(p2) if m['add_key'] == NK(rbx)), None)
case('...and the stickiness is bounded: a spot that is clearly worse (a 3.5/wk player for a 1.0) is not kept', m2 is not None and m2['drop_name'] != _worse[1], m2 and m2['drop_name'])

# ---------------------------------------------------------------- 8e. displacement chain (10-13: 'start Pierce at RB2' with no one named)
# A free RB arrives; the optimizer puts him at RB2 and slides the old RB2 to W/R/T, whose
# occupant (a bye TE) goes to the bench. The newcomer is 'over' that TE, not over nobody.
r8e = bsb_roster(open_spots=1)
r8e = [(sl, n, ps, tm, (0.0 if sl == 'W/R/T' else pt), d) for sl, n, ps, tm, pt, d in r8e]
flex_name = next(x[1] for x in r8e if x[0] == 'W/R/T')
rbc = 'Peregrine Ashdown'
f, st, pr = league('BSB', r8e, fas=[(rbc, 'RB', 'PHI', 13.0)], kicks={'CLE': None}, byes={W1: set()}, usage={NK(rbc): dict(START, pos='RB')})
ev = dict(breakout_rows=[dict(key=NK(rbc), name=rbc, pos='RB', tm='PHI', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
m = next((m for m in moves_of(p) if m['add_key'] == NK(rbc)), None)
case('a newcomer who starts via a slot shuffle is paired with the starter the shuffle pushes out', m is not None and ((m.get('lineup') or {}).get('over') or '').startswith(flex_name), (m and m.get('lineup'), p.summary()[:300]))

# ---------------------------------------------------------------- 8f. HH acquisitions are cheap late in the week (10-18)
import lib.rules as _RU2
case('rules: an HH acquisition costs full price on Tuesday with 7 left', _RU2.acq_price(C.week_start(WEEK) + C.dt.timedelta(hours=1), 7) == 1.0)
case('rules: ...and a fifth of that on Saturday with 4+ left', _RU2.acq_price(C.week_start(WEEK) + C.dt.timedelta(days=4), 7) == 0.2)
case('rules: ...but full price on Saturday when only 2 are left', _RU2.acq_price(C.week_start(WEEK) + C.dt.timedelta(days=4), 2) == 1.0)
case('rules: BSB (no cap) is unaffected', _RU2.acq_price(C.week_start(WEEK) + C.dt.timedelta(days=4), None) == 1.0)

# ---------------------------------------------------------------- 8g. playoff weighting (10-18): a locked-in team is judged on weeks 15-17
# Two free WRs, equal this week and next: one is a December asset (his team's implied
# totals rise in weeks 15-17), the other fades. With P(playoffs) = 1 the planner prefers
# the December man; with P(playoffs) = 0 the two tie and the rest-of-season mean decides.
r8g = bsb_roster(open_spots=1)
dec, fade = 'Caspian Wintermere', 'Orlo Summerfield'
class _PW(FakeWindows):
    def __init__(self, byes=None): super().__init__(byes); self.rank_ = {}
# season blend gives both the same rest-of-season per-week value; playoff weeks are read
# per week through f.value -> ros_pw, so we tilt the December man by registering a
# higher ros for weeks 15-17 only via a per-week override hook if the harness has one;
# otherwise the case checks the term is wired: dS_play reported and weighted by q.
f, st, pr = league('BSB', r8g, fas=[(dec, 'WR', 'PHI', 14.0)], byes={W1: set()}, usage={NK(dec): dict(START, pos='WR')})
ev = dict(breakout_rows=[dict(key=NK(dec), name=dec, pos='WR', tm='PHI', tier='A', held='wk5', usage='', market='', in_pool=True, ahead=True)], p_playoffs=1.0)
p = PL.plan_facts(f, ev)
m = next((m for m in moves_of(p) if m['add_key'] == NK(dec)), None)
case('playoff term: with P(playoffs)=1 the move reports its weeks-15-17 value and the weight', m is not None and m['value_terms'].get('p_playoffs') == 1.0 and 'dS_play' in m['value_terms'], m and m['value_terms'])
f2, st2, pr2 = league('BSB', r8g, fas=[(dec, 'WR', 'PHI', 14.0)], byes={W1: set()}, usage={NK(dec): dict(START, pos='WR')})
p2 = PL.plan_facts(f2, dict(ev, p_playoffs=0.0))
m2 = next((m for m in moves_of(p2) if m['add_key'] == NK(dec)), None)
case('playoff term: with P(playoffs)=0 the term contributes nothing', m2 is not None and abs(m2['J'] - (m['J'] - PL.W_PLAY * 1.0 * m['value_terms']['dS_play'])) < 1e-6, (m and m['J'], m2 and m2['J']))

# ---------------------------------------------------------------- 8h. QB2 insurance in a one-QB league (Caleb, 10-24)
# "Given how important QB is, is it not worth keeping a backup?" A roster with ONE QB, a
# junk bench WR and a spare DEF; the best free QB (17/wk) is a registry priority-2 add.
# The point terms alone never ship a backup who never starts; the insurance term does,
# and the spot is the junk WR, not the spare DEF (10-24: the hand-picked 49ers drop).
r8h = bsb_roster(extra=[('BN', 'Kansas City', 'DEF', 'KC', 6.5, 'none')])
r8h = [r for r in r8h if not (r[0] == 'BN' and r[3] == 'LV')]          # keep 18: drop the 1.0 WR, keep the 2.5 and 3.0 WRs as the junk
junk = [r for r in r8h if r[0] == 'BN' and r[2] not in ('DEF', 'K')]          # any bench skill player; never the spare DEF
qb2 = 'Thackeray Bellweather'
# the starter's bye sits two weeks out while byes still exist (as Stafford's week 11 did);
# the insurance term alone is a near-miss by design (~3 J late in the year) — it is the
# bye cover PLUS insurance that ships, never insurance over a real player
_qb_bye = WEEK + 2 if WEEK + 2 <= 14 else None
_byes8h = {W1: set()}
if _qb_bye: _byes8h[_qb_bye] = {'DAL'}
f, st, pr = league('BSB', r8h, fas=[(qb2, 'QB', 'TB', 17.0), ('Dallas Cowboys', 'DEF', 'DAL', 7.5), ('Ambrose Fennimore', 'QB', 'NYJ', 14.0)],
                   byes=_byes8h,
                   registry=dict(verified={NK(qb2): dict(priority=2, why='QB2 insurance (test)', team='TB', pos='QB', as_of=NOW.date().isoformat())}))
p = PL.plan_facts(f, dict(p_playoffs=1.0))
m8h = next((m for m in moves_of(p) if m['add_key'] == NK(qb2)), None)
_ins_terms = m8h['value_terms'] if m8h else next((r.get('terms') or {} for r in p.rejected if r['key'] == NK(qb2)), {})
case('QB2 insurance: the term is explicit and positive for a one-QB roster', (_ins_terms.get('d_ins') or 0) > 0, _ins_terms)
if _qb_bye:
    case('QB2 insurance: with the starter\'s bye ahead, a one-QB roster adds the best free QB as a backup', m8h is not None, p.summary())
    case('...the spot is the weakest bench skill player, never the spare DEF', m8h is not None and m8h.get('spot_kind') == 'drop' and m8h.get('drop_name') in {r[1] for r in junk}, m8h and (m8h.get('spot_kind'), m8h.get('drop_name')))
# control: a roster that already carries two QBs earns no insurance credit for a third
r8h2 = bsb_roster(extra=[('BN', 'Ignatius Pemberton', 'QB', 'SEA', 15.0, 'none')])
r8h2 = [r for r in r8h2 if not (r[0] == 'BN' and r[3] == 'LV')]
f2, st2, pr2 = league('BSB', r8h2, fas=[(qb2, 'QB', 'TB', 17.0)], byes={W1: set()},
                      registry=dict(verified={NK(qb2): dict(priority=2, why='QB2 insurance (test)', team='TB', pos='QB', as_of=NOW.date().isoformat())}))
obj2 = PL.Objective(f2, PL.Mechanics(f2))
case('...a roster with two QBs already gets no insurance credit for a third', obj2.insurance([(f2.fa(NK(qb2)), None, 'W')]) == 0.0)
# control: a superflex league (two QB-eligible slots) is not a one-QB league
f3, st3, pr3 = league('HH', hh_roster(), fas=[(qb2, 'QB', 'TB', 30.0)], byes={W1: set()})
case('...superflex is not a one-QB league: no insurance term', not PL.Objective(f3, PL.Mechanics(f3)).one_qb())

# ---------------------------------------------------------------- 9. handcuff never a drop
r9 = bsb_roster()
hc = r9[-1][1]
f, st, pr = league('BSB', r9, fas=[('Peregrine Ashdown', 'WR', 'PIT', 30.0)],
                   registry=dict(hold={NK(hc): dict(handcuff_for='The Starter', call='HOLD — handcuff', why='RB2 behind the starter')}))
ev = dict(breakout_rows=[dict(key=NK('Peregrine Ashdown'), name='Peregrine Ashdown', pos='WR', tm='PIT', tier='A', held='', usage='', market='', in_pool=True, ahead=True)])
p = PL.plan_facts(f, ev)
case('a handcuff is never the drop', not any(t['op'] == 'drop' and t['key'] == NK(hc) for m in p.moves for t in m['txns']), p.summary())
case('...and is listed as not a clean drop', any(e['player'] == hc for e in p.excluded))

# ---------------------------------------------------------------- 10. HH acquisition cap
log = [dict(datetime=(NOW - C.dt.timedelta(minutes=10 + i)).strftime('%Y-%m-%d %H:%M'), team=S.ALL['HH'].name, action='Add', player=f'Somebody {i}', note='Free Agent')
       for i in range(6)]
r10 = hh_roster()[:-2]                               # two open spots
c1, c2 = 'Leofric Wetherby', 'Godwin Ashbury'
f, st, pr = league('HH', r10, fas=[(c1, 'WR', 'PIT', 30.0), (c2, 'WR', 'NYJ', 29.0)], log_rows=log, registry=dict(drop_ok={}))
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(c1), name=c1, week=30.0), over=dict(player='x', pts=12.0)),
                    dict(fam='WR', add=dict(key=NK(c2), name=c2, week=29.0), over=dict(player='x', pts=12.0))])
p = PL.plan_facts(f, ev)
case('HH cap: 6 of 7 used since Tuesday -> 1 left', f.acq_left == 1, str(f.acq_left))
adds = moves_of(p)
case('HH cap respected: one add this week, the other rejected on the cap', len([m for m in adds if m['eff'] == 'W']) == 1 and any('acquisition cap' in r['reason'] for r in p.rejected), p.summary() + str(p.rejected))
case('the HH reset day is marked unverified', p.budgets.get('acq_reset_verified') is False and any(not e['verified'] and '7 acquisitions' in e['rule'] for e in p.mechanics))

# ---------------------------------------------------------------- 11. BSB claim vs free agent
r11 = bsb_roster(open_spots=2)
fa_ok, fa_kicked, fa_waived = 'Hildebrand Oyelaran', 'Mstislav Kowalczyk', 'Radomir Etxeberria'
f, st, pr = league('BSB', r11, fas=[(fa_ok, 'WR', 'PIT', 25.0), (fa_kicked, 'WR', 'NYJ', 24.0), (fa_waived, 'WR', 'PHI', 23.0)],
                   kicks={'PIT': FUT, 'NYJ': PAST, 'PHI': FUT}, waived={NK(fa_waived): 'Sat 4:05 am'})
M = PL.Mechanics(f)
a_ok, a_k, a_w = M.acquire(f.fa(NK(fa_ok))), M.acquire(f.fa(NK(fa_kicked))), M.acquire(f.fa(NK(fa_waived)))
case('BSB: a never-rostered FA before his kickoff is a free-agent add', a_ok['kind'] == 'fa' and a_ok['eff'] == 'W', str(a_ok))
case('BSB: an unrostered player whose game kicked off is a CLAIM that plays next week', a_k['kind'] == 'claim' and a_k['eff'] == 'W+1' and 'claim by Tue night' in a_k['label'], str(a_k))
case('BSB: a player dropped to waivers is a CLAIM', a_w['kind'] == 'claim', str(a_w))
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(x), name=x, week=20.0), over=dict(player='x', pts=9.0)) for x in (fa_ok, fa_kicked, fa_waived)])
p = PL.plan_facts(f, ev)
byk = {m['add_key']: m for m in moves_of(p)}
case('BSB plan: the free agent is an add "before kickoff"', NK(fa_ok) in byk and byk[NK(fa_ok)]['when'].startswith('before kickoff') and byk[NK(fa_ok)]['txns'][0]['op'] == 'add', p.summary())
claimed = [byk[k] for k in (NK(fa_kicked), NK(fa_waived)) if k in byk]
case('BSB plan: a waiver player, when proposed, is a claim with a bid (never an add)', all(m['txns'][0]['op'] == 'claim' and m['txns'][0].get('bid') is not None for m in claimed), str(claimed))
case('BSB plan: FAB spent <= FAB left', sum((t.get('bid') or 0) for m in p.moves for t in m['txns'] if t['op'] == 'claim') <= f.fab_left)
fh, _, _ = league('HH', hh_roster()[:-1], fas=[('Ostrogoth Pemberley', 'WR', 'PIT', 25.0)], kicks={'PIT': PAST}, registry=dict(drop_ok={}))
ah = PL.Mechanics(fh).acquire(fh.fa(NK('Ostrogoth Pemberley')))
case('HH: a free agent whose game is in progress is addable after the game', ah['kind'] == 'after_game', str(ah))

# ---------------------------------------------------------------- 12. deterministic and idempotent
r12 = bsb_roster(open_spots=1)
d1 = 'Evander Quillfeather'
f, st, pr = league('BSB', r12, fas=[(d1, 'WR', 'PIT', 25.0)], byes={W1: {'SEA'}}, kicks={'PIT': FUT})
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(d1), name=d1, week=25.0), over=dict(player='x', pts=9.0))])
before = copy.deepcopy([{k: v for k, v in r.items() if k not in ('line',)} for r in st.rows])
j1 = PL.plan_facts(f, ev).to_json(); j2 = PL.plan_facts(f, ev).to_json()
case('plan is deterministic (same inputs -> identical JSON)', j1 == j2)
after = [{k: v for k, v in r.items() if k not in ('line',)} for r in st.rows]
case('planning mutates nothing (roster rows unchanged)', before == after)
p1 = json.loads(j1)
added = [m for m in p1['moves'] if m['kind'] == 'add']
# apply the plan's moves to the roster and plan again: nothing left to do
r12b = list(r12)
for m in added:
    for t in m['txns']:
        if t['op'] == 'drop': r12b = [x for x in r12b if NK(x[1]) != t['key']]
    for t in m['txns']:
        if t['op'] in ('add', 'claim'):
            fa_row = f.fa(t['key'])
            r12b.append(('BN', fa_row.name, fa_row.pos, fa_row.tm, fa_row.pts_w, 'none'))
case('the plan made at least one add to re-check', len(added) >= 1, j1[:400])
fb, _, _ = league('BSB', r12b, fas=[], byes={W1: {'SEA'}}, kicks={'PIT': FUT})
pb = PL.plan_facts(fb, dict(upgrades=[]))
case('idempotent: after applying the plan, re-planning proposes no further adds', not moves_of(pb), pb.summary())

# ---------------------------------------------------------------- 12b. joint re-evaluation: two WRs for one flex
r12c = bsb_roster(open_spots=2)
for i in (3, 4, 5): r12c[i] = (r12c[i][0], r12c[i][1], 'WR', r12c[i][3], 20.0, 'none')
g1, g2 = 'Aldous Wintergreen', 'Benedikt Haverstock'
f, st, pr = league('BSB', r12c, fas=[(g1, 'WR', 'PIT', 15.0), (g2, 'WR', 'NYJ', 14.5)], kicks={'PIT': FUT, 'NYJ': FUT})
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(x), name=x, week=15.0), over=dict(player='x', pts=9.5)) for x in (g1, g2)])
p = PL.plan_facts(f, ev)
adds = moves_of(p)
case('joint re-evaluation: two WRs that each beat the flex alone -> only one ships', len(adds) == 1 and adds[0]['add_key'] == NK(g1), p.summary())
case('...the other is rejected on its value given the rest of the plan', any(r['key'] == NK(g2) and 'jointly' in r['reason'] for r in p.rejected), str(p.rejected))

# ---------------------------------------------------------------- 13. sanity: the plan simulation check
from lib import sanity as SAN
r13 = bsb_roster(open_spots=1)
e1, e2 = 'Athelstan Merryweather', 'Ethelred Moonbeam'
f, st, pr = league('BSB', r13, fas=[(e1, 'WR', 'PIT', 25.0), (e2, 'WR', 'NYJ', 24.0)], kicks={'PIT': FUT, 'NYJ': FUT})
ev = dict(upgrades=[dict(fam='WR', add=dict(key=NK(x), name=x, week=25.0), over=dict(player='x', pts=9.0)) for x in (e1, e2)])
p = PL.plan_facts(f, ev)
runlike = dict(leagues={'BSB': dict(state=st)}, plans={'BSB': p}, week=WEEK)
case('sanity: the real plan simulates clean', SAN.check_plan(runlike) == [], str(SAN.check_plan(runlike)))
pb_ = copy.deepcopy(p)
am = [m for m in pb_.moves if m['kind'] == 'add']
if len(am) >= 2: am[1]['spot_id'] = am[0]['spot_id']
case('sanity: a spot used twice is caught', len(am) >= 2 and any('twice' in x for x in SAN.check_plan(dict(runlike, plans={'BSB': pb_}))))
pc_ = copy.deepcopy(p)
pc_.moves.append(dict(id='bad', kind='add', spot_id='zz', provisional=False, eff='W', txns=[dict(op='add', player='x', key='x'), dict(op='add', player='y', key='y')]))
case('sanity: an add past roster size is caught', any('active roster' in x for x in SAN.check_plan(dict(runlike, plans={'BSB': pc_}))))
pd_ = copy.deepcopy(p)
pd_.moves.append(dict(id='bad2', kind='add', spot_id='zz2', provisional=False, eff='W', txns=[dict(op='drop', player='Nobody Here', key='nobody here')]))
case('sanity: a drop of a player not on the roster is caught', any('not on the active roster' in x for x in SAN.check_plan(dict(runlike, plans={'BSB': pd_}))))
pe_ = copy.deepcopy(p); pe_.budgets = dict(pe_.budgets, fab_left=0)
pe_.moves.append(dict(id='bad3', kind='add', spot_id='zz3', provisional=False, eff='W+1', txns=[dict(op='claim', player='z', key='z', bid=5)]))
case('sanity: FAB over budget is caught', any('FAB' in x for x in SAN.check_plan(dict(runlike, plans={'BSB': pe_}))))

# 10-06: a kicker/defense add never costs a skill player or an IDP — it swaps one-for-one
# with the spare/only K or DEF, or takes an open/dead spot (Boswell-for-Kelce at J +11).
try:
    _r = PL._spot_rule if hasattr(PL, '_spot_rule') else None
except Exception: _r = None
case('rule text exists: a K/DEF never costs a non-K/DEF player', 'kickers and defenses swap one-for-one' in open('/home/claude/bsb2/lib/plan.py').read())


# ---------------------------------------------------------------- 14. the best DEF in the league is never the stream's spot (11-10, Caleb: "dropping the vikings is crazy")
# BSB, three defenses: the Vikings (first in the league on the field, 10/wk rest-of-season,
# an ordinary matchup this week), the 49ers (6.6), the Commanders (5.5, the Thursday stream).
# A free Ravens unit beats all three THIS week (8.7) and is worth 4/wk after; a free Eagles
# unit carries a HIGHER rest-of-season number than the Vikings but sits on bye. The engine
# (V144) named the Vikings: their key sorted first, every DEF looked fungible against the
# Eagles' stream value, and the spare was chosen on the preseason blend.
_byes14 = {WEEK: {'PHI'}, W1: set()}
r14 = bsb_roster(def_tm='MIN', extra=[('BN', 'San Francisco', 'DEF', 'SF', 4.6, 'none'), ('BN', 'Washington Commanders', 'DEF', 'WAS', 6.3, 'none')])
r14 = [r for r in r14 if not (r[0] == 'BN' and r[3] in ('LV', 'LAC'))]
r14 = [(r[0], r[1], r[2], r[3], 6.0, r[5]) if r[0] == 'DEF' else r for r in r14]
_vik14 = next(r[1] for r in r14 if r[0] == 'DEF')                       # the roster's name for DST:MIN
f, st, pr = league('BSB', r14, fas=[('Baltimore Ravens', 'DEF', 'BAL', 8.7), ('Philadelphia Eagles', 'DEF', 'PHI', None)], byes=_byes14)
_ros14 = {'DST:MIN': 10.0, 'DST:SF': 6.6, 'DST:WAS': 5.5}
for k, d in f.mine.items():
    if k in _ros14: d['ros_pw'] = _ros14[k]; d['ros_src'] = 'test'; d['pts_w1'] = _ros14[k] * 0.7
_fa_bal = f.fa('DST:BAL'); _fa_bal['ros_pw'] = 4.0; _fa_bal['pts_w1'] = 7.5
_fa_phi = f.fa('DST:PHI'); _fa_phi['ros_pw'] = 7.5; _fa_phi['pts_w1'] = 7.5; _fa_phi['pts_w'] = None
f._pool_cache['DST:BAL'] = _fa_bal; f._pool_cache['DST:PHI'] = _fa_phi
_ev14 = dict(upgrades=[dict(fam='DEF', add=dict(key='DST:BAL', name='Baltimore Ravens', week=8.7), over=dict(player='Washington Commanders', pts=6.3))])
p = PL.plan_facts(f, _ev14)
_sp14 = {s_['id']: s_ for s_ in p.spots}
case('three DEFs: the spare is the weakest rest-of-season (the Commanders), not the alphabet', _sp14.get('drop:DST:WAS', {}).get('kind') == 'spare' and _sp14.get('drop:DST:MIN', {}).get('kind') != 'spare', str([(k, v['kind'], v['tier']) for k, v in _sp14.items() if 'DST' in k]))
case('...a third defense makes the spare a dead spot (tier 0)', _sp14.get('drop:DST:WAS', {}).get('tier') == 0, str(_sp14.get('drop:DST:WAS')))
m14 = next((m for m in moves_of(p) if m['add_key'] == 'DST:BAL'), None)
case('...the Ravens never cost the Vikings: the spot is the spare or nothing', m14 is None or (m14.get('drop_name') != _vik14 and m14.get('spot_id') != 'drop:DST:MIN'), m14 and (m14.get('drop_name'), m14.get('spot_id'), m14.get('value_terms')))
_bal_best = (m14.get('spot_id') if m14 else None) or next((('drop:DST:WAS' if 'Washington Commanders' in r['reason'] else r['reason']) for r in p.rejected if r['key'] == 'DST:BAL'), None)
case('...the Ravens\' best spot is the spare Commanders (ship or not)', _bal_best == 'drop:DST:WAS', str(_bal_best))
_rej14 = next((r for r in p.rejected if r['key'] == 'DST:BAL'), None)
case('...and a one-for-one on the Vikings is refused by rule, not by arithmetic', any('not the spare DEF' in str(v.get('reason')) for v in [PL._eval_pair(f, PL.Mechanics(f), PL.Objective(f), c_, _sp14 and PL.Spot(id='drop:DST:MIN', kind='swap', tier=2, fact=f.mine['DST:MIN'], fam='DEF', label='Minnesota Vikings', n_fam=3), {'DEF': 7.5}) for c_ in PL.produce(f, _ev14) if c_.key == 'DST:BAL']), str([v.get('reason') for v in [PL._eval_pair(f, PL.Mechanics(f), PL.Objective(f), c_, PL.Spot(id='drop:DST:MIN', kind='swap', tier=2, fact=f.mine['DST:MIN'], fam='DEF', label='Minnesota Vikings', n_fam=3), {'DEF': 7.5}) for c_ in PL.produce(f, _ev14) if c_.key == 'DST:BAL']]))
# the stream phantom restores the slot, it never upgrades it: cutting the Vikings must read
# as a loss in the rest weeks even with the Eagles' higher number on the wire
_obj14 = PL.Objective(f, PL.Mechanics(f))
_t14 = _obj14.terms([(_fa_bal, f.mine['DST:MIN'], 'W')], dict(acq=1, bid=1, txn=1))
case('...cutting the best DEF is a rest-of-season loss, whatever free unit has a bigger preseason number', _t14['dS_rest'] < -1.0, str(_t14))
_t14b = _obj14.terms([(_fa_bal, f.mine['DST:WAS'], 'W')], dict(acq=1, bid=1, txn=1))
case('...cutting the spare costs nothing after this week', _t14b['dS_rest'] > -0.01 and _t14b['dS_W'] > 2.0, str(_t14b))
# a registry HOLD on the Vikings removes them from the spots entirely
f2, st2, pr2 = league('BSB', r14, fas=[('Baltimore Ravens', 'DEF', 'BAL', 8.7)], byes=_byes14, registry=dict(hold={'DST:MIN': dict(why='first in the league on the field', call='HOLD')}))
p2 = PL.plan_facts(f2, _ev14)
case('...a held DEF is not a spot at all', not any(s_['id'] == 'drop:DST:MIN' for s_ in p2.spots) and any(e['player'] == _vik14 and 'HOLD' in e['reason'] for e in p2.excluded), str(p2.excluded))

# ---------------------------------------------------------------- 14b. the realized season blends into rest-of-season value (lib/ytd.py)
from lib import ytd as YTD
_v, _why = YTD.blend(121.6 / 17, dict(pts=78.0, gp=7), 'DEF')
case('ytd: 7 games at 11.1/g pull a 7.2/wk preseason DEF to ~10/wk (3-game prior)', 9.8 < _v < 10.1, f'{_v:.2f} {_why}')
_v2, _ = YTD.blend(128.0 / 17, dict(pts=23.0, gp=8), 'DEF')
case('ytd: 8 games at 2.9/g pull a 7.5/wk preseason DEF under 4.5/wk', _v2 < 4.5, f'{_v2:.2f}')
_v3, _ = YTD.blend(10.0, dict(pts=80.0, gp=8), 'WR')
case('ytd: a skill player keeps 6 games of prior (8 games at 10/g on a 10/wk prior stays 10)', abs(_v3 - 10.0) < 1e-9, f'{_v3:.2f}')
case('ytd: no games, no blend', YTD.blend(10.0, dict(pts=0.0, gp=0), 'WR') is None and YTD.blend(10.0, None, 'WR') is None)
r14b = bsb_roster(def_tm='MIN')
f3, st3, pr3 = league('BSB', r14b, season={'DST:MIN': dict(pts=121.6, pos='DEF', name='Minnesota Vikings', tm='MIN')})
f4 = Facts.from_parts('BSB', st3, pr3, WEEK, NOW, f3.wire, LU.solve(st3, pr3), windows=FakeWindows(None), season={'DST:MIN': dict(pts=121.6, pos='DEF', name='Minnesota Vikings', tm='MIN')},
                      ytd={'DST:MIN': dict(pts=78.0, gp=7, ppg=78 / 7, weeks=list(range(2, 10)), pos='DEF')}, usage_week=WEEK - 1)
case('facts: a DEF with a realized record is valued on it (9.9/wk, not the 7.2 preseason)', 9.8 < (f4.mine['DST:MIN'].ros_pw or 0) < 10.1 and 'realized' in f4.mine['DST:MIN'].ros_src, (f4.mine['DST:MIN'].ros_pw, f4.mine['DST:MIN'].ros_src))
case('facts: without a record the preseason number stands', abs((f3.mine['DST:MIN'].ros_pw or 0) - 121.6 / 17) < 1e-6, f3.mine['DST:MIN'].ros_pw)

# ---------------------------------------------------------------- 14c. a Tier-B the crowd is adding is bid to clear the ladder, not $1 (11-10: Estime)
_m14c = PL.Mechanics(f)
_m14c._trend = {'DST:BAL'}
_cB = next(c_ for c_ in PL.produce(f, _ev14) if c_.key == 'DST:BAL')
_m14c._cand = _cB
_bid_tr = _m14c.bid(_fa_bal, 'B')
_m14c._trend = set()
_bid_quiet = _m14c.bid(_fa_bal, 'B')
case('bid: a trending Tier-B clears the ladder\'s top decile (>= the firm bid), a quiet one pays the band-B dollar', _bid_tr >= max(_bid_quiet, 1) and (_bid_tr > _bid_quiet or _bid_quiet > 1), (_bid_tr, _bid_quiet))


# ---------------------------------------------------------------- 15. a spot freed by the joint pass is re-offered (11-10: Dicker took the spare DEF over Estime, then died next to Zvada)
# BSB, week-11 K bye: two free kickers both cover it (the second is worthless next to the
# first), three DEFs (the spare is a dead spot), and a free RB who is a real two-week
# upgrade at the spare. The Hungarian pass seats K1 on the kicker and K2 on the spare DEF
# (a higher total than the RB); the joint pass removes K2. The RB must then get the spare.
r15 = bsb_roster(def_tm='MIN', k_tm='SEA', extra=[('BN', 'San Francisco', 'DEF', 'SF', 4.6, 'none'), ('BN', 'Washington Commanders', 'DEF', 'WAS', 6.3, 'none')])
r15 = [r for r in r15 if not (r[0] == 'BN' and r[3] in ('LV', 'LAC'))]
r15 = [(r[0], r[1], r[2], r[3], 6.0, r[5]) if r[0] == 'DEF' else r for r in r15]
_k15 = next(r for r in r15 if r[0] == 'K')
_rb15 = 'Audric Estime'
f, st, pr = league('BSB', r15, fas=[('Dominic Zvada', 'K', 'DET', 9.0), ('Cameron Dicker', 'K', 'LAC', 8.8), (_rb15, 'RB', 'NO', 9.0)],
                   byes={WEEK: set(), W1: {_k15[3]}})
for k, d in f.mine.items():
    if k in ('DST:MIN', 'DST:SF', 'DST:WAS'): d['ros_pw'] = {'DST:MIN': 10.0, 'DST:SF': 6.6, 'DST:WAS': 5.5}[k]; d['ros_src'] = 'test'; d['pts_w1'] = d['ros_pw'] * 0.7
for r in r15:
    if r[2] == 'RB': f.mine[NK(r[1])]['pts_w1'] = 0.0                                      # every RB sits next week (bye): the free RB starts
    if r[0] == 'BN' and r[2] != 'DEF': f.mine[NK(r[1])]['ros_pw'] = 20.0                   # the bench is real players: the spare DEF is the only spot worth J >= 3
for nmk, kk in ((NK('Dominic Zvada'), 12.8), (NK('Cameron Dicker'), 12.5)):      # both K covers outscore the RB on their own; only one survives jointly
    x = f.fa(nmk); x['pts_w1'] = kk; x['ros_pw'] = kk; f._pool_cache[nmk] = x
x = f.fa(NK(_rb15)); x['pts_w1'] = 8.0; x['ros_pw'] = 8.0; x['usage_now'] = 'start'; f._pool_cache[NK(_rb15)] = x
_ev15 = dict(upgrades=[dict(fam='RB', add=dict(key=NK(_rb15), name=_rb15, week=9.0), over=dict(player='x', pts=1.5))])
p = PL.plan_facts(f, _ev15)
_mv15 = {m['add_key']: m for m in moves_of(p)}
case('re-solve: one K cover ships for the week-11 bye, not two', sum(1 for k in _mv15 if k in (NK('Dominic Zvada'), NK('Cameron Dicker'))) == 1, str([(k, m.get('drop_name')) for k, m in _mv15.items()]))
case('...and the RB displaced by the doomed second K ships once the assignment is re-solved', NK(_rb15) in _mv15 and _mv15[NK(_rb15)]['J'] >= PL.SHIP_J, str([(k, m.get('drop_name'), m.get('spot_id'), m['J']) for k, m in _mv15.items()] + [(r['name'], r['reason'][:140]) for r in p.rejected if r['key'] == NK(_rb15)]))
case('...nobody is told his spot "went to another move" that never shipped', not any('went to another move' in r['reason'] for r in p.rejected), str([(r['name'], r['reason'][:100]) for r in p.rejected if 'went to' in r['reason']]))


# ---------------------------------------------------------------- 16. a lineup call's deadline is the EARLIER lock of the two men (11-11: Curl over Cross)
THU = NOW + C.dt.timedelta(hours=8)            # tonight
SUN = NOW + C.dt.timedelta(days=3)
r16 = bsb_roster()
_wr16 = [r for r in r16 if r[0] == 'WR']
_bn16 = next(r for r in r16 if r[0] == 'BN' and r[2] == 'WR')
r16 = [(r[0], r[1], r[2], r[3], 20.0, r[5]) if r[1] == _bn16[1] else r for r in r16]        # the bench WR outscores a starter
_sit16 = _wr16[-1]                                                                        # the weakest starting WR (9.0)
f, st, pr = league('BSB', r16, kicks={_sit16[3]: THU, _bn16[3]: SUN})
p = PL.plan_facts(f, dict())
_lm16 = next((m for m in moves_of(p, 'lineup') if m.get('start') == _bn16[1]), None)
case('lineup deadline: a Sunday starter over a Thursday sitter is due before the Thursday lock', _lm16 is not None and _lm16.get('deadline') == C.iso(THU), _lm16 and (_lm16.get('sit'), _lm16.get('deadline'), C.iso(THU)))


# ---------------------------------------------------------------- 17. QB for QB (11-18, Caleb: "douglas has been a really good wr, are we sure he is the drop?")
# BSB, one QB slot: the starter on bye, the QB2 hurt (no number this week, blocked by the
# drop gate on thin data), a real bench WR at 7.9/wk, a free QB at 20.9. V154 named the WR.
r17 = bsb_roster(qb_tm='LAR', extra=[('BN', 'Bakari Mayfold', 'QB', 'TB', 0.0, 'Q')])
r17 = [r for r in r17 if not (r[0] == 'BN' and r[3] == 'LV')]
_qb17 = next(r for r in r17 if r[0] == 'QB')
r17 = [(r[0], r[1], r[2], r[3], 0.0, r[5]) if r[0] == 'QB' else r for r in r17]             # the starter is on bye
_wr17 = next(r for r in r17 if r[0] == 'BN' and r[2] == 'WR')
jh = 'Justus Herbwright'
_sea17 = {NK('Bakari Mayfold'): dict(name='Bakari Mayfold', tm='TB', pos='QB', pts=272.0), NK(_qb17[1]): dict(name=_qb17[1], tm='LAR', pos='QB', pts=404.0)}
f, st, pr = league('BSB', r17, fas=[(jh, 'QB', 'LAC', 20.9)], kicks={'LAR': None}, byes={WEEK: {'LAR'}, W1: set()}, season=_sea17)
f.mine[NK(_qb17[1])]['ros_pw'] = 23.8; f.mine[NK(_qb17[1])]['pts_w1'] = 23.8
f.mine[NK('Bakari Mayfold')]['ros_pw'] = 16.0; f.mine[NK('Bakari Mayfold')]['pts_w1'] = 16.0
f.mine[NK(_wr17[1])]['ros_pw'] = 7.9
x = f.fa(NK(jh)); x['ros_pw'] = 17.3; x['pts_w1'] = 17.3; f._pool_cache[NK(jh)] = x
_ev17 = dict(upgrades=[dict(fam='QB', add=dict(key=NK(jh), name=jh, week=20.9), over=dict(player=_qb17[1], pts=0.0))])
p = PL.plan_facts(f, _ev17)
m17 = next((m for m in moves_of(p) if m['add_key'] == NK(jh)), None)
case('QB for QB: the bye/injury cover ships', m17 is not None, p.summary())
case('...and the drop is the QB2 he replaces, never a real bench WR', m17 is not None and m17.get('drop_name') == 'Bakari Mayfold', m17 and (m17.get('drop_name'), m17.get('spot_kind'), m17.get('value_terms')))
case('...and the move carries no BLOCK on its drop gate (the card refuses a blocked action)', m17 is not None and (m17['gates']['drop'] or {}).get('verdict') != 'BLOCK', m17 and m17['gates'])
case('...the bench QB is replaced, not lost: no depth charge when the new QB2 is the better one', m17 is not None and m17['value_terms']['d_depth'] > -0.01, m17 and m17['value_terms'])
_sp17 = PL.Spot(id='drop:' + NK(_wr17[1]), kind='drop', tier=3, fact=f.mine[NK(_wr17[1])], fam='WR', label=_wr17[1])
_c17 = next(c for c in PL.produce(f, _ev17) if c.key == NK(jh))
_e17 = PL._eval_pair(f, PL.Mechanics(f), PL.Objective(f), _c17, _sp17, {})
case('...a third QB is refused the WR by rule', not _e17['feasible'] and 'third QB' in (_e17['reason'] or ''), _e17['reason'])
# a non-QB add never takes the QB2
_spq = next(s_ for s_ in PL.SpotPool(f, PL.Mechanics(f)).spots if s_.id == 'drop:' + NK('Bakari Mayfold'))
f2, st2, pr2 = league('BSB', r17, fas=[('Wendel Tierayson', 'WR', 'DEN', 15.0)], kicks={'LAR': None}, byes={WEEK: {'LAR'}, W1: set()}, season=_sea17)
# when the QB2 is not a spot at all (held), the hole may still take a bench body: no dead end
f3, st3, pr3 = league('BSB', r17, fas=[(jh, 'QB', 'LAC', 20.9)], kicks={'LAR': None}, byes={WEEK: {'LAR'}, W1: set()}, season=_sea17, registry=dict(hold={NK('Bakari Mayfold'): dict(why='hold (test)', call='HOLD')}))
p3 = PL.plan_facts(f3, _ev17)
case('...a held QB2 is no spot, and the cover is not dead-ended by the third-QB rule', f3.spare_qb is None and not any('third QB' in r['reason'] for r in p3.rejected), str([(r['name'], r['reason'][:120]) for r in p3.rejected]))
_cw = PL.Candidate(key=NK('Wendel Tierayson'), name='Wendel Tierayson', fact=f2.fa(NK('Wendel Tierayson')), srcs={'breakout'}, tier='A', reasons=[], hole=None, held=False, firm=False)
case('...and the QB2 is never the spot for a non-QB add', 'QB-for-QB' in (PL.pair_block(f, _cw, _spq, {}) or ''), PL.pair_block(f, _cw, _spq, {}))

print('=' * 88)
print(f'{total - bad}/{total} behaved as required.' + ('  PLANNER IS SOUND.' if not bad else '  PLANNER FAILED.'))
sys.exit(1 if bad else 0)
