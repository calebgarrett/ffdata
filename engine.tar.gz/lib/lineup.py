"""ONE LINEUP SOLVER, both leagues. Returns a DIFF against live slots.

Exact max-weight assignment (Hungarian) over every slot the league has, with
Yahoo's own eligibility. Then three things the old per-league scripts got wrong:

  1. Compared against what is ACTUALLY STARTING, so a change is only a change if
     the set of starters changes. "Swap in the 49ers" (09-16) cannot happen.
  2. A pure permutation of the same players across interchangeable slots
     (Oluokun <-> Schwesinger between D and LB, 09-16) is net zero and is not
     reported as two moves.
  3. Every change carries the game's lineup phase from the clock, so a Sunday
     call on a Tuesday is labelled 'early' and PROVISIONAL rather than shouted.
     Caleb: "Don't worry about lineup changes unless it's at least 1 day before
     the game."
"""
import numpy as np
from scipy.optimize import linear_sum_assignment
from . import clock as C, score as SC
from .rules import UNUSABLE, locked
from .facts import _fam

NOISE = 1.5    # inside this many points, two players are the same player

def solve(state, proj, actuals=None):
    """-> dict(optimal={slot:row}, current={slot:row}, changes=[...], total_cur, total_opt,
               unknown=[rows nobody projects], perms=[slots that merely permuted])"""
    cfg = state.cfg; slots = cfg.slots
    rows = []
    for r in state.mine:
        if r['slot'] == 'IR': continue
        L = proj.line(r['key'], r['pos'], r['tm'])
        r['line'] = L
        r['pts'] = SC.points(L, state.league)
        r['boom'] = SC.boom(L, state.league)
        r['kick'] = proj.kickoff(r['tm'])
        r['phase'] = C.lineup_phase(r['kick'])
        r['ready'] = proj.market_ready(r['tm'])
        a = (actuals or {}).get(r['key'])
        r['final'] = bool(a) and a['final']
        r['live'] = bool(a) and not a['final']
        if a:
            from . import actuals as AC
            r['actual'] = a['pts']; r['frac'] = a['frac']; r['boom'] = None; r['ready'] = True
            r['proj_pts'] = r['pts']
            # final: the number is a fact. In progress: live points so far plus the
            # unplayed share of the projection. Either way the slot is locked.
            r['pts'] = AC.blend(a, r['pts']); r['phase'] = 'final' if a['final'] else 'live'
        rows.append(r)
    # Yahoo's lock is part of the problem, not a filter on the answer: a player
    # whose game has kicked off stays exactly where he is — a locked starter keeps
    # his slot, a locked bench player cannot enter (10-03: Boston scored 17.6 on
    # Thursday from the bench and the 'optimal' total counted him at W/R)
    _locked = locked
    cur_slot = {r['key']: s for s, r in state.current_lineup().items() if r}
    R = [r for r in rows if r['designation'] not in UNUSABLE and r['pts'] is not None and not (_locked(r) and r['key'] not in cur_slot)]
    # an OUT starter who is locked also keeps his slot (nothing can replace him now)
    R += [r for r in rows if r['designation'] in UNUSABLE and _locked(r) and r['key'] in cur_slot and r not in R]
    Cm = np.full((len(R), len(slots)), 1e6)
    for i, r in enumerate(R):
        for j, s in enumerate(slots):
            if _locked(r) and r['key'] in cur_slot:
                if s == cur_slot[r['key']]: Cm[i, j] = -(r['pts'] or 0.0) - 1e3     # pinned
                continue
            if r['elig'] & cfg.accepts[s]: Cm[i, j] = -r['pts']
    ri, ci = linear_sum_assignment(Cm)
    opt = {s: None for s in slots}
    for i, j in zip(ri, ci):
        if Cm[i, j] < 1e5: opt[slots[j]] = R[i]
    cur = state.current_lineup()

    cur_set = {r['key'] for r in cur.values() if r}
    opt_set = {r['key'] for r in opt.values() if r}
    real_in, real_out = opt_set - cur_set, cur_set - opt_set
    changes, perms = [], []
    unclaimed = set(real_out)          # each displaced starter is named once (Cross/Odunze 09-23)
    # who each newcomer displaces: the optimizer permutes equivalent slots (QB <-> Q/W/R/T,
    # TE <-> W/R/T), so the man 'in that slot now' is often still a starter elsewhere.
    # Pair every incoming player with a displaced starter ELIGIBLE for the slot he takes —
    # most constrained slot first, same family preferred, then the slot's current occupant,
    # then the lowest projection (10-13: 'QB Stafford over Chase', 'Pierce over Vikings').
    out_rows = {r['key']: r for r in cur.values() if r and r['key'] in real_out}
    def _chain(s):
        # the starter the newcomer in slot s actually pushes out: follow the occupant of s to
        # wherever the optimizer moved him, until someone lands on the bench (10-13)
        r = cur.get(s); seen = set()
        while r is not None and r['key'] not in seen:
            if r['key'] in unclaimed: return r['key']
            seen.add(r['key'])
            s2 = next((z for z, rr in opt.items() if rr and rr['key'] == r['key'] and z != s), None)
            if s2 is None: return None
            r = cur.get(s2)
        return None
    pairing = {}
    pending = [s for s in slots if opt.get(s) and opt[s]['key'] in real_in]
    while pending:
        opts_ = {s: [k for k in unclaimed if out_rows[k]['elig'] & cfg.accepts[s]] for s in pending}
        s = min(pending, key=lambda z: (len(opts_[z]), slots.index(z)))
        o = opt[s]; c = cur.get(s); cand = opts_[s]
        ch = _chain(s)
        if ch:
            pairing[s] = out_rows[ch]; unclaimed.discard(ch)
        elif cand:
            cand.sort(key=lambda k: (0 if _fam(out_rows[k]['pos']) == _fam(o['pos']) else 1, 0 if (c and k == c['key']) else 1, out_rows[k]['pts'] or 0.0, k))
            pairing[s] = out_rows[cand[0]]; unclaimed.discard(cand[0])
        else:
            pairing[s] = None
        pending.remove(s)
    for s in slots:
        c, o = cur.get(s), opt.get(s)
        if (c and o and c['key'] == o['key']) or (c is None and o is None): continue
        # a permutation: both players are starters either way
        if (not o or o['key'] in cur_set) and (not c or c['key'] in opt_set):
            perms.append(s); continue
        if o and o['key'] in real_in:
            # locked either way (final, live, or past kickoff): Yahoo locks a player at his
            # kickoff, so a swap involving anyone whose game has started is not a move that
            # can be made (Douglas for Likely at 2:20 pm, 09-27). One predicate: rules.locked.
            if _locked(o) or (c and _locked(c)): continue
            # who does he displace? the starter in real_out with the same slot-family, else any
            out = pairing.get(s)
            gain = (o['pts'] or 0) - ((out['pts'] or 0) if out else 0)
            # a Q/D starter projected at exactly 0 is a source ASSUMING he is out
            # (Sleeper zeroes injured players; Cross 09-23). That is a game-status
            # question, not a lineup edge: provisional, with the reason named.
            q_zero = bool(out) and out.get('designation') in ('Q', 'D') and not (out['pts'] or 0)
            # a starter Yahoo tags OUT (O/IR/PUP/SUSP/NA) is a hole, not a lineup edge:
            # replacing him is FIRM whatever the market has or has not posted (Burns,
            # torn ACL, 09-29: 'Watt over Burns — not a move until the market posts')
            sit_out = bool(out) and (out.get('designation') in UNUSABLE
                                     # or he has no game this week (bye): the slot scores 0 — a hole, not an edge (10-06)
                                     or (out.get('kick') is None and not (out.get('pts') or 0)))
            hole = out is None and c is None            # an EMPTY slot: filling it is firm whatever the market says (10-14: DEF empty after a drop)
            # the newcomer's slot is held by someone who merely SLIDES to another slot: say so,
            # or 'Strong at RB2 over Douglas' reads as nonsense (10-17)
            slide = ''
            if c and out and c['key'] != out['key']:
                s2 = next((z for z, rr in opt.items() if rr and rr['key'] == c['key'] and z != s), None)
                if s2: slide = f" ({c['player']} slides to {s2})"
            changes.append(dict(slot=s, start=o, sit=out, gain=gain,
                                provisional=(not sit_out) and (not hole) and ((gain < NOISE) or not o['ready'] or (bool(out) and not out.get('ready', True)) or bool(o['line'].get('partial')) or q_zero),
                                reason=((f"{out['player']} is {out['designation']} — the slot scores nothing until he is replaced" if out.get('designation') in UNUSABLE
                                         else f"{out['player']} has no game this week (bye) — the slot scores nothing until he is replaced") if sit_out else
                                        'the slot is empty — it scores nothing until someone is in it' if hole else
                                        f"{out['player']} is {out['designation']} and projected 0.00 — the source assumes he is OUT; if he is active he keeps the slot" if q_zero else '') + slide,
                                slide=slide.strip(),
                                phase=o['phase'], kick=o['kick']))
    tot = lambda d: sum((r['pts'] or 0) for r in d.values() if r)      # the pin bonus is not in r['pts'], so totals are honest
    return dict(optimal=opt, current=cur, changes=changes, perms=perms,
                total_cur=tot(cur), total_opt=tot(opt), rows=rows,
                unknown=[r for r in rows if r['pts'] is None and r['designation'] not in UNUSABLE])

def optimal_points(rows, cfg, values, locks=None):
    """PURE optimal lineup: no state, no projections, no mutation (the planner's
    objective evaluates hundreds of hypothetical rosters with it).

      rows    [{'key', 'elig'}, ...] — the active roster (IR slots already excluded)
      cfg     the league config (slots, accepts)
      values  {key: points} — None or a missing key means he cannot start this week
              (unusable designation, unknown projection, on waivers until later)
      locks   {key: slot} — Yahoo's lock: a key pinned to a starting slot keeps it
              (his value counts as given, 0 if None); a key locked to 'BN' (or to any
              non-starting place) cannot enter the lineup.
    -> (total, {slot: key or None})"""
    locks = locks or {}
    slots = list(cfg.slots)
    out = {s: None for s in slots}
    total = 0.0
    free_slots = list(slots)
    for k, s in locks.items():
        if s in out and out[s] is None:
            out[s] = k; total += float(values.get(k) or 0.0); free_slots.remove(s)
    R = [r for r in rows if r['key'] not in locks and values.get(r['key']) is not None]
    if not R or not free_slots: return total, out
    Cm = np.full((len(R), len(free_slots)), 1e6)
    for i, r in enumerate(R):
        v = float(values[r['key']])
        for j, s in enumerate(free_slots):
            if r['elig'] & cfg.accepts[s]: Cm[i, j] = -v
    ri, ci = linear_sum_assignment(Cm)
    for i, j in zip(ri, ci):
        if Cm[i, j] < 1e5:
            out[free_slots[j]] = R[i]["key"]; total += float(-Cm[i, j])
    return total, out
