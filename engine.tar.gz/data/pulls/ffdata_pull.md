# ffdata pull loaded Tue Oct 27, 10:05 pm ET — repo head: 2026-10-28T00:27:19+00:00 pull 2026-10-28T00:27Z
week 8
runner state adopted: the pump runner's ledger (2026-10-27 20:26) was newer than the local one (2026-10-25 09:55) — 52 files copied (C17)
kalshi.csv: 1380 markets, 87 events, pulled 2026-10-28T00:24:27+00:00
kalshi_archive: 13 new pull(s) copied, 175 on disk
espn_games.csv: 14 games for week 8 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk8.csv: 3302 rows
sleeper_idp_wk8.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk7_QB.csv: 74 rows
usage_wk7_RB.csv: 152 rows
usage_wk7_WR.csv: 252 rows
usage_wk7_TE.csv: 149 rows
BSB rosters: pump pull 2026-10-28T00:25:17+00:00 is not newer than the snapshot on disk (2026-10-28T00:25:17+00:00)
BSB matchup wk8: vs Ex-Presidents; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 6 new of 48 on the page; log now 265 rows
HH rosters: pump pull 2026-10-28T00:25:17+00:00 is not newer than the snapshot on disk (2026-10-28T00:25:17+00:00)
HH matchup wk8: vs The STRIB Club; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 16 new of 42 on the page; log now 225 rows
