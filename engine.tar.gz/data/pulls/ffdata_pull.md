# ffdata pull loaded Sun Sep 27, 2:33 pm ET — repo head: 2026-09-27T18:22:40+00:00 pull 2026-09-27T18:22Z
week 3
kalshi.csv: 5293 markets, 173 events, pulled 2026-09-27T18:19:17+00:00
kalshi_archive: 1 new pull(s) copied, 17 on disk
espn_games.csv: 16 games for week 3 — 5 with ESPN lines from the pump, 11 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk3.csv: 3305 rows
sleeper_idp_wk3.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk2_QB.csv: 84 rows
usage_wk3_QB.csv: 53 rows
usage_wk2_RB.csv: 179 rows
usage_wk3_RB.csv: 107 rows
usage_wk2_WR.csv: 280 rows
usage_wk3_WR.csv: 179 rows
usage_wk2_TE.csv: 165 rows
usage_wk3_TE.csv: 96 rows
BSB rosters: 216 players on 12 teams, pulled 2026-09-27T18:20:36+00:00 -> new snapshot
BSB matchup wk3: vs Rayland; 4 final rows, 0 in progress; totals me 32.20 opp 6.60
BSB transactions: 0 new of 36 on the page; log now 69 rows
HH rosters: 235 players on 10 teams, pulled 2026-09-27T18:20:36+00:00 -> new snapshot
HH matchup wk3: vs Grey Poop On Bijan Mustard; 2 final rows, 0 in progress; totals me 38.27 opp 0.00
HH transactions: 0 new of 40 on the page; log now 59 rows
