# ffdata pull loaded Sat Oct 17, 12:05 pm ET — repo head: 2026-10-17T14:26:08+00:00 pull 2026-10-17T14:26Z
week 6
runner state adopted: the pump runner's ledger (2026-10-17 10:25) was newer than the local one (2026-10-16 07:52) — 45 files copied (C17)
kalshi.csv: 4290 markets, 148 events, pulled 2026-10-17T14:22:01+00:00
kalshi_archive: 7 new pull(s) copied, 114 on disk
espn_games.csv: 14 games for week 6 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk6.csv: 3302 rows
sleeper_idp_wk6.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk5_QB.csv: 81 rows
usage_wk5_RB.csv: 167 rows
usage_wk5_WR.csv: 265 rows
usage_wk5_TE.csv: 160 rows
BSB rosters: pump pull 2026-10-17T14:23:03+00:00 is not newer than the snapshot on disk (2026-10-17T14:23:03+00:00)
BSB matchup wk6: vs Deadites; 2 final rows, 0 in progress; totals me 34.30 opp 0.00
BSB transactions: 2 new of 46 on the page; log now 199 rows
HH rosters: pump pull 2026-10-17T14:23:03+00:00 is not newer than the snapshot on disk (2026-10-17T14:23:03+00:00)
HH matchup wk6: vs My Team is on IR; 2 final rows, 0 in progress; totals me 0.00 opp 29.00
HH transactions: 0 new of 46 on the page; log now 170 rows
