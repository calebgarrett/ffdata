# ffdata pull loaded Tue Oct 6, 5:53 pm ET — repo head: 2026-10-06T21:35:44+00:00 pull 2026-10-06T21:35Z
week 5
kalshi.csv: 1575 markets, 91 events, pulled 2026-10-06T21:33:40+00:00
kalshi_archive: 4 new pull(s) copied, 61 on disk
espn_games.csv: 15 games for week 5 — 0 with ESPN lines from the pump, 15 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk5.csv: 3304 rows
sleeper_idp_wk5.csv: 4603 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk4_QB.csv: 85 rows
usage_wk4_RB.csv: 179 rows
usage_wk4_WR.csv: 283 rows
usage_wk4_TE.csv: 165 rows
BSB rosters: 216 players on 12 teams, pulled 2026-10-06T21:34:32+00:00 -> new snapshot
BSB matchup wk5: vs Phish Phanatics; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 0 new of 36 on the page; log now 97 rows
HH rosters: 239 players on 10 teams, pulled 2026-10-06T21:34:32+00:00 -> new snapshot
HH matchup wk5: vs Maker's Mark; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 8 new of 33 on the page; log now 104 rows
