# ffdata pull loaded Tue Nov 24, 9:28 am ET — repo head: 2026-11-24T14:28:18+00:00 pull 2026-11-24T14:28Z
week 12
runner state adopted: the pump runner's ledger (2026-11-24 09:27) was newer than the local one (2026-11-21 10:18) — 54 files copied (C17)
kalshi.csv: 2377 markets, 97 events, pulled 2026-11-24T14:24:48+00:00
kalshi_archive: 6 new pull(s) copied, 281 on disk
espn_games.csv: 16 games for week 12 — 0 with ESPN lines from the pump, 16 schedule-only from lines_wk10_18.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk12.csv: 3307 rows
sleeper_idp_wk12.csv: 4603 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk11_QB.csv: 75 rows
usage_wk11_RB.csv: 146 rows
usage_wk11_WR.csv: 236 rows
usage_wk11_TE.csv: 137 rows
usage_wk11_K.csv: 29 rows
usage_wk11_DEF.csv: 26 rows
BSB rosters: pump pull 2026-11-24T14:25:38+00:00 is not newer than the snapshot on disk (2026-11-24T14:25:38+00:00)
BSB matchup wk12: vs Regulators; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 10 new of 50 on the page; log now 403 rows
HH rosters: pump pull 2026-11-24T14:25:38+00:00 is not newer than the snapshot on disk (2026-11-24T14:25:38+00:00)
HH matchup wk12: vs Grey Poop On Bijan Mustard; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 4 new of 38 on the page; log now 372 rows
