# ffdata pull loaded Wed Nov 4, 10:22 pm ET — repo head: 2026-11-05T01:28:06+00:00 pull 2026-11-05T01:28Z
week 9
runner state adopted: the pump runner's ledger (2026-11-04 20:27) was newer than the local one (2026-11-04 01:43) — 36 files copied (C17)
kalshi.csv: 3186 markets, 133 events, pulled 2026-11-05T01:25:25+00:00
kalshi_archive: 3 new pull(s) copied, 208 on disk
espn_games.csv: 15 games for week 9 — 0 with ESPN lines from the pump, 15 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk9.csv: 3304 rows
sleeper_idp_wk9.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk8_QB.csv: 78 rows
usage_wk8_RB.csv: 148 rows
usage_wk8_WR.csv: 244 rows
usage_wk8_TE.csv: 149 rows
BSB rosters: pump pull 2026-11-05T01:26:28+00:00 is not newer than the snapshot on disk (2026-11-05T01:26:28+00:00)
BSB matchup wk9: vs 65 SOUTH; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 8 new of 40 on the page; log now 317 rows
HH rosters: pump pull 2026-11-05T01:26:28+00:00 is not newer than the snapshot on disk (2026-11-05T01:26:28+00:00)
HH matchup wk9: vs T-rex; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 5 new of 45 on the page; log now 260 rows
