# ffdata pull loaded Wed Nov 4, 1:21 am ET — repo head: 2026-11-04T06:02:31+00:00 pull 2026-11-04T06:02Z
week 9
runner state adopted: the pump runner's ledger (2026-11-04 01:01) was newer than the local one (2026-10-31 19:40) — 48 files copied (C17)
kalshi.csv: 2096 markets, 109 events, pulled 2026-11-04T05:59:12+00:00
kalshi_archive: 10 new pull(s) copied, 205 on disk
espn_games.csv: 15 games for week 9 — 0 with ESPN lines from the pump, 15 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk9.csv: 3304 rows
sleeper_idp_wk9.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk8_QB.csv: 78 rows
usage_wk8_RB.csv: 148 rows
usage_wk8_WR.csv: 244 rows
usage_wk8_TE.csv: 149 rows
BSB rosters: pump pull 2026-11-04T06:00:05+00:00 is not newer than the snapshot on disk (2026-11-04T06:00:05+00:00)
BSB matchup wk9: vs 65 SOUTH; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 4 new of 42 on the page; log now 309 rows
HH rosters: pump pull 2026-11-04T06:00:05+00:00 is not newer than the snapshot on disk (2026-11-04T06:00:05+00:00)
HH matchup wk9: vs T-rex; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 18 new of 45 on the page; log now 255 rows
