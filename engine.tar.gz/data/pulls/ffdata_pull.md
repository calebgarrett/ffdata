# ffdata pull loaded Tue Nov 10, 9:50 pm ET — repo head: 2026-11-11T02:44:13+00:00 pull 2026-11-11T02:44Z
week 10
runner state adopted: the pump runner's ledger (2026-11-10 21:43) was newer than the local one (2026-11-10 21:24) — 32 files copied (C17)
kalshi.csv: 2081 markets, 102 events, pulled 2026-11-11T02:41:32+00:00
kalshi_archive: 1 new pull(s) copied, 232 on disk
espn_games.csv: 14 games for week 10 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk10_18.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk10.csv: 3302 rows
sleeper_idp_wk10.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk9_QB.csv: 86 rows
usage_wk9_RB.csv: 168 rows
usage_wk9_WR.csv: 264 rows
usage_wk9_TE.csv: 159 rows
usage_wk2_K.csv: 35 rows
usage_wk3_K.csv: 35 rows
usage_wk4_K.csv: 36 rows
usage_wk5_K.csv: 34 rows
usage_wk6_K.csv: 31 rows
usage_wk7_K.csv: 33 rows
usage_wk8_K.csv: 34 rows
usage_wk9_K.csv: 36 rows
usage_wk2_DEF.csv: 32 rows
usage_wk3_DEF.csv: 32 rows
usage_wk4_DEF.csv: 32 rows
usage_wk5_DEF.csv: 30 rows
usage_wk6_DEF.csv: 28 rows
usage_wk7_DEF.csv: 28 rows
usage_wk8_DEF.csv: 28 rows
usage_wk9_DEF.csv: 30 rows
BSB rosters: pump pull 2026-11-11T02:42:25+00:00 is not newer than the snapshot on disk (2026-11-11T02:42:25+00:00)
BSB matchup wk10: vs WINdianapolis; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 0 new of 40 on the page; log now 329 rows
HH rosters: pump pull 2026-11-11T02:42:25+00:00 is not newer than the snapshot on disk (2026-11-11T02:42:25+00:00)
HH matchup wk10: vs Pound the Rock; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 0 new of 45 on the page; log now 300 rows
