# ffdata pull loaded Tue Nov 10, 9:23 pm ET — repo head: 2026-11-11T00:52:21+00:00 pull 2026-11-11T00:52Z
week 10
kalshi.csv: 1720 markets, 94 events, pulled 2026-11-11T00:50:27+00:00
kalshi_archive: 9 new pull(s) copied, 231 on disk
espn_games.csv: 14 games for week 10 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk10_18.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk10.csv: 3302 rows
sleeper_idp_wk10.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk9_QB.csv: 86 rows
usage_wk9_RB.csv: 168 rows
usage_wk9_WR.csv: 264 rows
usage_wk9_TE.csv: 159 rows
BSB rosters: 216 players on 12 teams, pulled 2026-11-11T00:51:10+00:00 -> new snapshot
BSB matchup wk10: vs WINdianapolis; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 2 new of 40 on the page; log now 329 rows
HH rosters: 237 players on 10 teams, pulled 2026-11-11T00:51:10+00:00 -> new snapshot
HH matchup wk10: vs Pound the Rock; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 30 new of 45 on the page; log now 300 rows
