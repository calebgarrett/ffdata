# ffdata pull loaded Fri Oct 23, 11:29 pm ET — repo head: 2026-10-24T03:25:41+00:00 pull 2026-10-24T03:25Z
week 7
runner state adopted: the pump runner's ledger (2026-10-23 23:24) was newer than the local one (2026-10-23 07:05) — 26 files copied (C17)
kalshi.csv: 4525 markets, 148 events, pulled 2026-10-24T03:21:25+00:00
kalshi_archive: 5 new pull(s) copied, 152 on disk
espn_games.csv: 14 games for week 7 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk7.csv: 3302 rows
sleeper_idp_wk7.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk6_QB.csv: 75 rows
usage_wk6_RB.csv: 160 rows
usage_wk6_WR.csv: 256 rows
usage_wk6_TE.csv: 148 rows
BSB rosters: pump pull 2026-10-24T03:22:49+00:00 is not newer than the snapshot on disk (2026-10-24T03:22:49+00:00)
BSB matchup wk7: vs Sycawhores; 4 final rows, 0 in progress; totals me 0.00 opp 51.70
BSB transactions: 2 new of 50 on the page; log now 251 rows
HH rosters: pump pull 2026-10-24T03:22:49+00:00 is not newer than the snapshot on disk (2026-10-24T03:22:49+00:00)
HH matchup wk7: vs Fumbling Idiot; 4 final rows, 0 in progress; totals me 0.00 opp 28.73
HH transactions: 2 new of 42 on the page; log now 195 rows
