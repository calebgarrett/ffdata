# ffdata pull loaded Sun Oct 18, 11:04 am ET — repo head: 2026-10-18T13:57:44+00:00 pull 2026-10-18T13:57Z
week 6
runner state adopted: the pump runner's ledger (2026-10-18 09:56) was newer than the local one (2026-10-18 01:05) — 26 files copied (C17)
kalshi.csv: 4657 markets, 149 events, pulled 2026-10-18T13:54:05+00:00
kalshi_archive: 2 new pull(s) copied, 121 on disk
espn_games.csv: 14 games for week 6 — 11 with ESPN lines from the pump, 3 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk6.csv: 3302 rows
sleeper_idp_wk6.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk5_QB.csv: 81 rows
usage_wk5_RB.csv: 167 rows
usage_wk6_RB.csv: 26 rows
usage_wk5_WR.csv: 265 rows
usage_wk6_WR.csv: 38 rows
usage_wk5_TE.csv: 160 rows
BSB rosters: pump pull 2026-10-18T13:55:10+00:00 is not newer than the snapshot on disk (2026-10-18T13:55:10+00:00)
BSB matchup wk6: vs Deadites; 2 final rows, 0 in progress; totals me 34.30 opp 0.00
BSB transactions: 12 new of 46 on the page; log now 217 rows
HH rosters: pump pull 2026-10-18T13:55:10+00:00 is not newer than the snapshot on disk (2026-10-18T13:55:10+00:00)
HH matchup wk6: vs My Team is on IR; 2 final rows, 0 in progress; totals me 0.00 opp 29.00
HH transactions: 2 new of 46 on the page; log now 172 rows
