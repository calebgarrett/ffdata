# ffdata pull loaded Sat Nov 21, 11:04 am ET — repo head: 2026-11-21T15:19:34+00:00 pull 2026-11-21T15:19Z
week 11
runner state adopted: the pump runner's ledger (2026-11-21 10:18) was newer than the local one (2026-11-20 13:00) — 38 files copied (C17)
kalshi.csv: 4665 markets, 149 events, pulled 2026-11-21T15:15:20+00:00
kalshi_archive: 3 new pull(s) copied, 271 on disk
espn_games.csv: 13 games for week 11 — 0 with ESPN lines from the pump, 13 schedule-only from lines_wk10_18.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk11.csv: 3301 rows
sleeper_idp_wk11.csv: 4603 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk10_QB.csv: 76 rows
usage_wk10_RB.csv: 157 rows
usage_wk10_WR.csv: 251 rows
usage_wk11_WR.csv: 20 rows
usage_wk10_TE.csv: 147 rows
usage_wk10_K.csv: 35 rows
usage_wk10_DEF.csv: 28 rows
BSB rosters: pump pull 2026-11-21T15:16:18+00:00 is not newer than the snapshot on disk (2026-11-21T15:16:18+00:00)
BSB matchup wk11: vs Short Bus; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 4 new of 50 on the page; log now 393 rows
HH rosters: pump pull 2026-11-21T15:16:18+00:00 is not newer than the snapshot on disk (2026-11-21T15:16:18+00:00)
HH matchup wk11: vs Eatin Pigskins; 4 final rows, 0 in progress; totals me 43.93 opp 50.13
HH transactions: 7 new of 36 on the page; log now 365 rows
