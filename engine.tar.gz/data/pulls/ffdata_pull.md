# ffdata pull loaded Fri Oct 2, 1:27 pm ET — repo head: 2026-10-02T16:16:15+00:00 pull 2026-10-02T16:16Z
week 4
kalshi.csv: 4849 markets, 166 events, pulled 2026-10-02T16:12:49+00:00
kalshi_archive: 4 new pull(s) copied, 41 on disk
espn_games.csv: 16 games for week 4 — 0 with ESPN lines from the pump, 16 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk4.csv: 3306 rows
sleeper_idp_wk4.csv: 4603 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk3_QB.csv: 85 rows
usage_wk3_RB.csv: 177 rows
usage_wk3_WR.csv: 282 rows
usage_wk3_TE.csv: 166 rows
BSB rosters: 216 players on 12 teams, pulled 2026-10-02T16:13:54+00:00 -> new snapshot
BSB matchup wk4: vs FWU; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 2 new of 33 on the page; log now 89 rows
HH rosters: 236 players on 10 teams, pulled 2026-10-02T16:13:54+00:00 -> new snapshot
HH matchup wk4: vs JETS; 4 final rows, 0 in progress; totals me 65.25 opp 0.00
HH transactions: 3 new of 38 on the page; log now 83 rows
