# ffdata pull loaded Tue Oct 20, 4:13 pm ET — repo head: 2026-10-20T17:30:54+00:00 pull 2026-10-20T17:30Z
week 7
kalshi.csv: 1277 markets, 78 events, pulled 2026-10-20T17:28:08+00:00
kalshi_archive: 0 new pull(s) copied, 133 on disk
espn_games.csv: 14 games for week 7 — 0 with ESPN lines from the pump, 14 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk7.csv: 3302 rows
sleeper_idp_wk7.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk6_QB.csv: 75 rows
usage_wk6_RB.csv: 160 rows
usage_wk6_WR.csv: 256 rows
usage_wk6_TE.csv: 148 rows
BSB rosters: pump pull 2026-10-20T17:28:56+00:00 is not newer than the snapshot on disk (2026-10-20T17:28:56+00:00)
BSB matchup wk7: vs Sycawhores; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 0 new of 47 on the page; log now 215 rows
HH rosters: pump pull 2026-10-20T17:28:56+00:00 is not newer than the snapshot on disk (2026-10-20T17:28:56+00:00)
HH matchup wk7: vs Fumbling Idiot; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 0 new of 45 on the page; log now 167 rows
