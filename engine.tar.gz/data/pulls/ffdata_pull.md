# ffdata pull loaded Thu Oct 29, 12:12 pm ET — repo head: 2026-10-29T09:49:51+00:00 pull 2026-10-29T09:49Z
week 8
kalshi.csv: 3291 markets, 131 events, pulled 2026-10-29T09:46:48+00:00
kalshi_archive: 0 new pull(s) copied, 181 on disk
espn_games.csv: 14 games for week 8 — 1 with ESPN lines from the pump, 13 schedule-only from lines_wk3_9.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk8.csv: 3302 rows
sleeper_idp_wk8.csv: 4604 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk7_QB.csv: 74 rows
usage_wk7_RB.csv: 152 rows
usage_wk7_WR.csv: 252 rows
usage_wk7_TE.csv: 149 rows
BSB rosters: pump pull 2026-10-29T09:47:49+00:00 is not newer than the snapshot on disk (2026-10-29T09:47:49+00:00)
BSB matchup wk8: vs Ex-Presidents; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 0 new of 48 on the page; log now 281 rows
HH rosters: pump pull 2026-10-29T09:47:49+00:00 is not newer than the snapshot on disk (2026-10-29T09:47:49+00:00)
HH matchup wk8: vs The STRIB Club; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 0 new of 42 on the page; log now 231 rows
