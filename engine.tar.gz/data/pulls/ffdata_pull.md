# ffdata pull loaded Wed Nov 18, 9:36 am ET — repo head: 2026-11-18T10:41:14+00:00 pull 2026-11-18T10:41Z
week 11
runner state adopted: the pump runner's ledger (2026-11-18 05:40) was newer than the local one (2026-11-17 15:00) — 36 files copied (C17)
kalshi.csv: 2832 markets, 113 events, pulled 2026-11-18T10:37:43+00:00
kalshi_archive: 2 new pull(s) copied, 259 on disk
espn_games.csv: 13 games for week 11 — 0 with ESPN lines from the pump, 13 schedule-only from lines_wk10_18.csv; Kalshi spread/total ladders supply the lines inside the engine
sleeper_off_wk11.csv: 3301 rows
sleeper_idp_wk11.csv: 4603 rows
trending_adds.csv: 40 adds / 40 drops (48h)
usage_wk10_QB.csv: 76 rows
usage_wk10_RB.csv: 157 rows
usage_wk10_WR.csv: 251 rows
usage_wk10_TE.csv: 147 rows
usage_wk10_K.csv: 35 rows
usage_wk10_DEF.csv: 28 rows
BSB rosters: pump pull 2026-11-18T10:38:45+00:00 is not newer than the snapshot on disk (2026-11-18T10:38:45+00:00)
BSB matchup wk11: vs Short Bus; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
BSB transactions: 8 new of 50 on the page; log now 381 rows
HH rosters: pump pull 2026-11-18T10:38:45+00:00 is not newer than the snapshot on disk (2026-11-18T10:38:45+00:00)
HH matchup wk11: vs Eatin Pigskins; 0 final rows, 0 in progress; totals me 0.00 opp 0.00
HH transactions: 0 new of 37 on the page; log now 348 rows
