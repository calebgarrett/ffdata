# Lineup Card — week 11

_Wed Nov 18, 9:48 am ET. Decisions first; detail folded below. A PROVISIONAL call waits for the market or a game-status answer._

## Decide (next 36 hours)

- BSB: **Add Justin Herbert** · drop DeMario Douglas — before kickoff Sun Nov 22, 4:05 pm ET
- BSB: **Start Ryan Flournoy at WR1** over Jaxon Smith-Njigba — before kickoff Sun Nov 22, 1:00 pm ET
- BSB: **Start Makai Lemon at WR3** over Drake London — before kickoff Sun Nov 22, 1:00 pm ET
- BSB: **Start 49ers at DEF** over Vikings — before kickoff Sun Nov 22, 8:20 pm ET
- HH: **Start Cooper DeJean at D** over Carson Schwesinger — before kickoff Sun Nov 22, 1:00 pm ET

## BSB — OVERKILL

16-4-0, 1st, PF — · projected 85 · 31% to beat Short Bus · 1% vs the league median
- Next lock: Sun Nov 22, 1:00 pm ET — 4 starters

<details><summary>Lineup after the moves</summary>

- DEF: 49ers
- K: Dominic Zvada
- QB: Justin Herbert
- RB1: James Cook III
- RB2: Audric Estime
- TE: Isaiah Likely
- W/R/T: Sam LaPorta
- WR1: Ryan Flournoy
- WR2: Malik Washington
- WR3: Makai Lemon

</details>

## HH — Tecmo Bowlers

8-2-0, 1st, PF — · projected 294 · 62% to beat Eatin Pigskins
- Next lock: Thu Nov 19, 8:15 pm ET — Texans

<details><summary>Lineup after the moves</summary>

- CB: Jalen Ramsey
- D: Cooper DeJean
- DB: Nick Cross
- DEF: Texans
- DL: T.J. Watt
- K: Brandon Aubrey
- LB: Foyesade Oluokun
- Q/W/R/T: Dak Prescott
- QB: Jared Goff
- RB: Jaylen Warren
- S: Budda Baker
- TE: Trey McBride
- W/R: Rashee Rice
- W/R/T: Rome Odunze
- WR: Ja'Marr Chase

</details>

<details><summary>BSB: considered, not moves (22)</summary>

- Carolina Panthers: J -0.51 < 3.0 at its best spot (49ers) — J -0.51 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(playoffs)
- Detroit Lions: J +0.22 < 3.0 at its best spot (49ers) — J +0.22 = 1.0x+0.72 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(playoffs)
- Los Angeles Chargers: J +0.27 < 3.0 at its best spot (49ers) — J +0.27 = 1.0x+0.77 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(playoffs)
- Andre Szmyt: J -0.69 < 3.0 at its best spot (Audric Estime) — J -0.69 = 1.0x+0.00 (wk W) + 0.8x+1.13 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(p
- Austin Ekeler: J -1.97 < 3.0 at its best spot (DeMario Douglas) — J -1.97 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P
- Brevyn Spann-Ford: J -1.44 < 3.0 at its best spot (Audric Estime) — J -1.44 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(p
- Charlie Kolar: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 3.9 under your weakest 10.0
- Chris Godwin Jr.: G15: dropped by Phish Phanatics on 2026-11-18 — a manager let a 175-point role go after his last game; find out why before claiming (a verified role is a regist
- Corey Kiner: best spot 49ers: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Dalton Schultz: J -1.37 < 3.0 at its best spot (Audric Estime) — J -1.37 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, P(p
- Dawson Knox: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 3.8 under your weakest 10.0
- Gunnar Helm: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 6.7 under your weakest 10.0

</details>

<details><summary>HH: considered, not moves (39)</summary>

- Adonai Mitchell: J -2.24 < 3.0 at its best spot (Devin Singletary) — J -2.24 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, 
- AJ Barner: best spot Steelers: Tier B (unpriced) never takes the spare DEF — Tier A only
- Alohi Gilman: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Austin Ekeler: J -2.24 < 3.0 at its best spot (Devin Singletary) — J -2.24 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, 
- Baker Mayfield: J -2.33 < 3.0 at its best spot (Devin Singletary) — J -2.33 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, 
- Barrett Carter: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Blake Corum: J -2.33 < 3.0 at its best spot (Devin Singletary) — J -2.33 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, 
- Bryan Cook: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Caleb Douglas: J -2.24 < 3.0 at its best spot (Devin Singletary) — J -2.24 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 13-17) + 0.60x+0.00 (wks 15-17, 
- Carnell Tate: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Charlie Kolar: best spot Steelers: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Corey Kiner: sits behind everyone: you carry 3 RBs for 1 slot(s) and he projects 0.0 under your weakest 3.8

</details>

<details><summary>Flags</summary>

- 2 DEFs rostered (Vikings, 49ers) for one DEF slot — the spare is 49ers (6.2/g over 8 games); the other is a registry hold
- Josh Jacobs [O] holds a roster spot — HOLD: HOLD, and START when active: a top-10 RB in the #9 December environment for the 
- 2 DEFs rostered — second one is a HOLD in a capped league: Texans (registry hold)

</details>

_Engine stamp Wed Nov 18, 9:48 am ET. The HTML card is the full record; this page is the private, phone-readable twin._
