# Lineup Card — week 9

_Wed Nov 4, 10:30 pm ET. Decisions first; detail folded below. A PROVISIONAL call waits for the market or a game-status answer._

## Decide (next 36 hours)

- BSB: **Start Isaiah Likely at W/R/T** over DeMario Douglas — before kickoff Sun Nov 8, 1:00 pm ET
- BSB: **Start 49ers at DEF** over Commanders — before kickoff Sun Nov 8, 4:25 pm ET

## BSB — OVERKILL

14-2-0, 1st, PF — · projected 142 · 51% to beat 65 SOUTH · 58% vs the league median
- Next lock: Sun Nov 8, 9:30 am ET — Drake London

<details><summary>Lineup after the moves</summary>

- DEF: 49ers
- K: Jason Myers
- QB: Matthew Stafford
- RB1: Josh Jacobs
- RB2: James Cook III
- TE: Sam LaPorta
- W/R/T: Isaiah Likely
- WR1: Jaxon Smith-Njigba
- WR2: Drake London
- WR3: Malik Washington

</details>

## HH — Tecmo Bowlers

6-2-0, 1st, PF — · projected 289 · 43% to beat T-rex
- Q/D: Rashee Rice, Carson Schwesinger, Kam Curl
- Next lock: Thu Nov 5, 8:15 pm ET — Foyesade Oluokun

<details><summary>Lineup after the moves</summary>

- CB: Cooper DeJean
- D: Foyesade Oluokun
- DB: Kam Curl
- DEF: Texans
- DL: T.J. Watt
- K: Brandon Aubrey
- LB: Carson Schwesinger
- Q/W/R/T: Jared Goff
- QB: Dak Prescott
- RB: Braelon Allen
- S: Budda Baker
- TE: Trey McBride
- W/R: Rashee Rice
- W/R/T: Ja'Marr Chase
- WR: Drake London

</details>

<details><summary>BSB: considered, not moves (17)</summary>

- Buffalo Bills: J +1.07 < 3.0 at its best spot (Vikings) — J +1.07 = 1.0x+0.00 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- New Orleans Saints: J +1.07 < 3.0 at its best spot (Vikings) — J +1.07 = 1.0x+0.00 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- New York Giants: J +1.30 < 3.0 at its best spot (Vikings) — J +1.30 = 1.0x+0.23 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- Austin Ekeler: J -1.04 < 3.0 at its best spot (DeMario Douglas) — J -1.04 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.44 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Brevyn Spann-Ford: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 2.6 under your weakest 10.7
- Chimere Dike: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 0.0 under your weakest 7.4
- Dalton Schultz: J -1.38 < 3.0 at its best spot (DeMario Douglas) — J -1.38 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Dominic Zvada: J +2.27 < 3.0 at its best spot (Jason Myers) — J +2.27 = 1.0x+0.00 (wk W) + 0.8x+1.43 (W+1) + 0.8x+1.76 (rest, mean of wks 11-17) + 0.60x+0.39 (wks 15-17, P(pla
- Eli Raridon: J -1.32 < 3.0 at its best spot (DeMario Douglas) — J -1.32 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Jake Ferguson: J -1.10 < 3.0 at its best spot (MarShawn Lloyd) — J -1.10 = 1.0x+0.00 (wk W) + 0.8x-0.31 (W+1) + 0.8x-0.21 (rest, mean of wks 11-17) + 0.60x-0.31 (wks 15-17, P(
- Jerry Jeudy: J -1.38 < 3.0 at its best spot (DeMario Douglas) — J -1.38 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Kyle Williams: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 3.9 under your weakest 7.4

</details>

<details><summary>HH: considered, not moves (41)</summary>

- Kansas City Chiefs: J +0.31 < 3.0 at its best spot (Commanders) — J +0.31 = 1.0x+1.30 (wk W) + 0.8x+0.63 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P(play
- AJ Barner: J -27.71 < 3.0 at its best spot (T.J. Watt) — J -27.71 = 1.0x+0.00 (wk W) + 0.8x-12.38 (W+1) + 0.8x-11.28 (rest, mean of wks 11-17) + 0.60x-12.38 (wks 15-17, P(
- Alohi Gilman: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Antonio Williams: sits behind everyone: you carry 6 WRs for 1 slot(s) and he projects 8.4 under your weakest 10.0
- Austin Booker: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Boye Mafe: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Brevyn Spann-Ford: best spot Commanders: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Caleb Douglas: sits behind everyone: you carry 6 WRs for 1 slot(s) and he projects 8.5 under your weakest 10.0
- Cam Bynum: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Carl Granderson: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Chig Okonkwo: best spot Commanders: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Chimere Dike: sits behind everyone: you carry 6 WRs for 1 slot(s) and he projects 0.0 under your weakest 10.0

</details>

<details><summary>Flags</summary>

- 3 DEFs rostered (Commanders, Vikings, 49ers) for one DEF slot — the spare is Commanders (73 season vs Vikings 122); Vikings is on the bench this week only on the matchup (5.2 vs 3.5), not on quality
- 2 DEFs rostered — second one is a HOLD in a capped league: Texans (registry hold)
- Rashee Rice is Q at W/R/T — if he is out, Jameson Williams (11.8) takes the slot; decide before Sun Nov 8, 1:00 pm ET
- Carson Schwesinger is Q at LB — if he is out, Quay Walker (17.6) takes the slot; decide before Sun Nov 8, 1:00 pm ET
- Kam Curl is Q at S — if he is out, Nick Cross (12.6) takes the slot; decide before Sun Nov 8, 1:00 pm ET

</details>

_Engine stamp Wed Nov 4, 10:30 pm ET. The HTML card is the full record; this page is the private, phone-readable twin._
