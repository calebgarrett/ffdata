# Lineup Card — week 8

_Wed Oct 28, 6:06 pm ET. Decisions first; detail folded below. A PROVISIONAL call waits for the market or a game-status answer._

## Decide (next 36 hours)

- BSB: **Start Ryan Flournoy at WR3** over Malik Washington _(provisional)_ — before kickoff Sun Nov 1, 1:00 pm ET
- HH: **Add Washington Commanders** · drop Alontae Taylor — before kickoff Sun Nov 1, 1:00 pm ET
- HH: **Start Rashee Rice at W/R/T** over Braelon Allen _(provisional)_ — before kickoff Sun Nov 1, 4:25 pm ET
- HH: **Start Jared Goff at Q/W/R/T** over Matthew Stafford _(provisional)_ — before kickoff Sun Nov 1, 1:00 pm ET
- HH: **Start Nick Cross at S** over Kam Curl _(provisional)_ — before kickoff Sun Nov 1, 8:20 pm ET

## BSB — OVERKILL

12-2-0, 1st, PF — · projected 135 · 77% to beat Ex-Presidents · 72% vs the league median
- Next lock: Thu Oct 29, 8:15 pm ET — Josh Jacobs

<details><summary>Lineup after the moves</summary>

- DEF: Minnesota
- K: Jason Myers
- QB: Matthew Stafford
- RB1: Josh Jacobs
- RB2: James Cook III
- TE: Sam LaPorta
- W/R/T: DeMario Douglas
- WR1: Jaxon Smith-Njigba
- WR2: Drake London
- WR3: Ryan Flournoy

</details>

## HH — Tecmo Bowlers

6-1-0, 1st, PF — · projected 292 · 36% to beat The STRIB Club
- Next lock: Sun Nov 1, 1:00 pm ET — 11 starters

<details><summary>Lineup after the moves</summary>

- CB: Cooper DeJean
- D: Foyesade Oluokun
- DB: Budda Baker
- DEF: Washington Commanders
- DL: T.J. Watt
- K: Brandon Aubrey
- LB: Carson Schwesinger
- Q/W/R/T: Jared Goff
- QB: Dak Prescott
- RB: Jaylen Warren
- S: Nick Cross
- TE: Trey McBride
- W/R: Drake London
- W/R/T: Rashee Rice
- WR: Ja'Marr Chase

</details>

<details><summary>BSB: considered, not moves (20)</summary>

- Cincinnati Bengals: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Jacksonville Jaguars: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Philadelphia Eagles: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Washington Commanders: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Dalton Schultz: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Dylan Sampson: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Elic Ayomanor: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 6.2 under your weakest 6.9
- Jake Ferguson: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Jerry Jeudy: gate: G1-owner league rosters last read Tue 10-27 8:25 PM ET, BEFORE the waiver run at Wed 6:00 AM — who is free is UNVERIFIED; read every roster (or the transa
- Jordan Watkins: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 0.0 under your weakest 6.9
- Kenny Gainwell: G15: dropped by 65 SOUTH on 2026-10-23 — a manager let a 151-point role go after his last game; find out why before claiming (a verified role is a registry add_
- Laquon Treadwell: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 3.6 under your weakest 6.9

</details>

<details><summary>HH: considered, not moves (38)</summary>

- Atlanta Falcons: jointly with the rest of the plan it adds only J -57.68 (< 3.0) — J -57.68 = 1.0x-19.22 (wk W) + 0.8x-16.80 (W+1) + 0.8x-16.80 (rest, mean of wks 10-17) + 0.60x
- Buffalo Bills: jointly with the rest of the plan it adds only J -56.48 (< 3.0) — J -56.48 = 1.0x-19.70 (wk W) + 0.8x-16.80 (W+1) + 0.8x-14.70 (rest, mean of wks 10-17) + 0.60x
- Dallas Cowboys: jointly with the rest of the plan it adds only J -64.60 (< 3.0) — J -64.60 = 1.0x-22.20 (wk W) + 0.8x-18.59 (W+1) + 0.8x-18.59 (rest, mean of wks 10-17) + 0.60x
- Detroit Lions: jointly with the rest of the plan it adds only J -3.63 (< 3.0) — J -3.63 = 1.0x-1.50 (wk W) + 0.8x-0.00 (W+1) + 0.8x-0.47 (rest, mean of wks 10-17) + 0.60x+0.00
- Kansas City Chiefs: you dropped him in HH on 2026-10-23 (<= 7 days, either league)
- New York Jets: jointly with the rest of the plan it adds only J -53.05 (< 3.0) — J -53.05 = 1.0x-16.63 (wk W) + 0.8x-16.63 (W+1) + 0.8x-14.55 (rest, mean of wks 10-17) + 0.60x
- Tampa Bay Buccaneers: jointly with the rest of the plan it adds only J -7.66 (< 3.0) — J -7.66 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x-3.71 (rest, mean of wks 10-17) + 0.60x+0.00
- AJ Barner: best spot Carson Schwesinger: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Alvin Kamara: sits behind everyone: you carry 2 RBs for 1 slot(s) and he projects 0.0 under your weakest 9.3
- Austin Booker: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Blake Corum: sits behind everyone: you carry 2 RBs for 1 slot(s) and he projects 7.5 under your weakest 9.3
- Boye Mafe: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])

</details>

<details><summary>Flags</summary>

- 2 DEFs rostered (Minnesota, San Francisco) for one DEF slot — the spare is San Francisco (85 season vs Minnesota 122)

</details>

_Engine stamp Wed Oct 28, 6:06 pm ET. The HTML card is the full record; this page is the private, phone-readable twin._
