# Lineup Card — week 9

_Wed Nov 4, 1:41 am ET. Decisions first; detail folded below. A PROVISIONAL call waits for the market or a game-status answer._

## Decide (next 36 hours)

- BSB: **Start Isaiah Likely at W/R/T** over DeMario Douglas _(provisional)_ — before kickoff Sun Nov 8, 1:00 pm ET
- BSB: **Start 49ers at DEF** over Commanders _(provisional)_ — before kickoff Sun Nov 8, 4:25 pm ET
- HH: **Start Texans at DEF** over Commanders _(provisional)_ — before kickoff Sun Nov 8, 4:05 pm ET
- HH: **Start Nick Cross at DB** over Kam Curl _(provisional)_ — before kickoff Sun Nov 8, 1:00 pm ET

## BSB — OVERKILL

14-2-0, 1st, PF — · projected 148 · 52% to beat 65 SOUTH · 68% vs the league median
- Q/D: Matthew Stafford
- Next lock: Sun Nov 8, 9:30 am ET — Drake London

<details><summary>Lineup after the moves</summary>

- DEF: 49ers
- K: Jason Myers
- QB: Matthew Stafford
- RB1: Josh Jacobs
- RB2: James Cook III
- TE: Sam LaPorta
- W/R/T: Isaiah Likely
- WR1: Drake London
- WR2: Jaxon Smith-Njigba
- WR3: Malik Washington

</details>

## HH — Tecmo Bowlers

6-2-0, 1st, PF — · projected 294 · 43% to beat T-rex
- Next lock: Thu Nov 5, 8:15 pm ET — Foyesade Oluokun

<details><summary>Lineup after the moves</summary>

- CB: Cooper DeJean
- D: Carson Schwesinger
- DB: Nick Cross
- DEF: Texans
- DL: T.J. Watt
- K: Brandon Aubrey
- LB: Foyesade Oluokun
- Q/W/R/T: Jared Goff
- QB: Dak Prescott
- RB: Braelon Allen
- S: Budda Baker
- TE: Trey McBride
- W/R: Ja'Marr Chase
- W/R/T: Rashee Rice
- WR: Drake London

</details>

<details><summary>BSB: considered, not moves (19)</summary>

- Buffalo Bills: J +1.06 < 3.0 at its best spot (Vikings) — J +1.06 = 1.0x+0.00 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- New Orleans Saints: J +1.06 < 3.0 at its best spot (Vikings) — J +1.06 = 1.0x+0.00 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- New York Giants: J +1.31 < 3.0 at its best spot (Vikings) — J +1.31 = 1.0x+0.25 (wk W) + 0.8x+1.29 (W+1) + 0.8x+0.38 (rest, mean of wks 11-17) + 0.60x+0.38 (wks 15-17, P(playoff
- Austin Ekeler: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Brevyn Spann-Ford: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 1.3 under your weakest 10.7
- Chimere Dike: sits behind everyone: you carry 6 WRs for 3 slot(s) and he projects 0.0 under your weakest 5.2
- Dalton Schultz: J -1.41 < 3.0 at its best spot (DeMario Douglas) — J -1.41 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Dominic Zvada: J +1.89 < 3.0 at its best spot (Jason Myers) — J +1.89 = 1.0x+0.00 (wk W) + 0.8x+0.95 (W+1) + 0.8x+1.76 (rest, mean of wks 11-17) + 0.60x+0.39 (wks 15-17, P(pla
- Efton Chism III: best spot Jason Myers: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Eli Raridon: sits behind everyone: you carry 2 TEs for 1 slot(s) and he projects 5.9 under your weakest 10.7
- Greg Dulcich: J -1.46 < 3.0 at its best spot (DeMario Douglas) — J -1.46 = 1.0x+0.00 (wk W) + 0.8x+0.00 (W+1) + 0.8x+0.00 (rest, mean of wks 11-17) + 0.60x+0.00 (wks 15-17, P
- Jake Ferguson: J -1.11 < 3.0 at its best spot (MarShawn Lloyd) — J -1.11 = 1.0x+0.00 (wk W) + 0.8x-0.31 (W+1) + 0.8x-0.21 (rest, mean of wks 11-17) + 0.60x-0.31 (wks 15-17, P(

</details>

<details><summary>HH: considered, not moves (43)</summary>

- Chicago Bears: J -3.03 < 3.0 at its best spot (Carson Schwesinger) — J -3.03 = 1.0x+0.00 (wk W) + 0.8x-0.39 (W+1) + 0.8x-0.90 (rest, mean of wks 11-17) + 0.60x-0.39 (wks 15-17
- Kansas City Chiefs: J -2.54 < 3.0 at its best spot (Carson Schwesinger) — J -2.54 = 1.0x+0.00 (wk W) + 0.8x+0.22 (W+1) + 0.8x-0.90 (rest, mean of wks 11-17) + 0.60x-0.39 (wks 15-17
- New York Giants: J -3.03 < 3.0 at its best spot (Carson Schwesinger) — J -3.03 = 1.0x+0.00 (wk W) + 0.8x-0.39 (W+1) + 0.8x-0.90 (rest, mean of wks 11-17) + 0.60x-0.39 (wks 15-17
- Abdul Carter: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- AJ Barner: J -27.71 < 3.0 at its best spot (T.J. Watt) — J -27.71 = 1.0x+0.00 (wk W) + 0.8x-12.38 (W+1) + 0.8x-11.28 (rest, mean of wks 11-17) + 0.60x-12.38 (wks 15-17, P(
- A.J. Haulcy: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Alohi Gilman: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Antonio Williams: sits behind everyone: you carry 6 WRs for 1 slot(s) and he projects 6.9 under your weakest 9.8
- Austin Booker: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Boye Mafe: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])
- Brevyn Spann-Ford: best spot Brandon Aubrey: Tier B on one week of usage: an open, IR or dead spot only — a real player waits for the second week
- Bryan Cook: gate: G5-sources SINGLE SOURCE: ['rotowire'] (['sleeper'])

</details>

<details><summary>Flags</summary>

- 3 DEFs rostered (Commanders, Vikings, 49ers) for one DEF slot — the spare is Commanders (73 season vs Vikings 122); Vikings is on the bench this week only on the matchup (5.2 vs 3.5), not on quality
- Matthew Stafford is Q at QB — if he is out, Baker Mayfield (18.3) takes the slot; decide before Sun Nov 8, 1:00 pm ET
- 2 DEFs rostered — second one is a HOLD in a capped league: Texans (registry hold)

</details>

_Engine stamp Wed Nov 4, 1:41 am ET. The HTML card is the full record; this page is the private, phone-readable twin._
